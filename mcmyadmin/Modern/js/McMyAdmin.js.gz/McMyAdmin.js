﻿/* 
#if !RELEASE
    if (getCookie("UNITTESTING") == "1")
    {
        document.write('<script type="text/javascript" src="/js/UnitTesting.js"></script>');
    }
#endif
*/

Extensions = {};

APICommands = {
    Login: "login",
    Logout: "logout",

    GetStatus: "getstatus",
    GetVersions: "getversions",
    GetTipOfDay: "gettip",
    GetExtensions: "getextensions",

    GetChat: "getchat",
    SendChat: "sendchat",

    StartServer: "startserver",
    StopServer: "stopserver",
    SleepServer: "SleepServer",
    RestartServer: "restartserver",
    KillServer: "killserver",

    GetFullConfig: "getfullconfig",
    SetConfig: "setconfig",

    GetSchedule: "getschedule",
    ResetSchedule: "setscheduledefaults",
    AddScheduleItem: "addscheduleitem",
    DeleteScheduleItem: "delscheduleitem",
    RunScheduleItem: "runscheduleitem",

    GetBackups: "GetBackups",
    TakeBackup: "TakeBackup",
    GetBackupStatus: "GetBackupStatus",
    DeleteBackup: "DeleteBackup",
    RestoreBackup: "RestoreBackup",
    DeleteWorld: "DeleteWorld",

    GetPlugins: "getplugins",
    SetPluginState: "setpluginstate",
    RefreshPlugins: "scanplugins",
    GetBukgetCategories: "GetBukgetCategories",
    GetBukgetPluginsInCategory: "GetBukgetPluginsInCategory",
    SearchBukget: "SearchBukget",
    GetBukgetPluginInfo: "GetBukgetPluginInfo",
    DownloadBukgetPlugin: "DownloadBukgetPlugin",

    GetGroupWarnings: "GetGroupWarnings",
    GetGroups: "getgrouplist",
    GetGroupInfo: "getgroupinfo",
    AddGroupValue: "addgroupvalue",
    RemoveGroupValue: "removegroupvalue",
    RenameGroup: "renamegroup",
    CreateGroup: "creategroup",
    DeleteGroup: "deletegroup",
    GetWorlds: "getworlds",
    ScanWorlds: "scanworlds",
    SetWorldBackup: "SetWorldBackup",

    GetUsers: "GetMCMAUsers",
    SetUserMask: "SetMCMAUserAuthMask",
    UnsetUserMask: "UnsetMCMAUserAuthMask",
    SetUserSetting: "SetMCMAUserSettingMask",
    UnsetUserSetting: "UnsetMCMAUserSettingMask",
    DeleteUser: "DeleteUser",
    CreateUser: "CreateUser",
    ChangeUserPassword: "ChangeUserPassword",
    ChangePassword: "ChangePassword",

    AddLicence: "AddLicence",
    UpdateMCMA: "updatemcma",
    UpdateMC: "updatemc",
    GetUpdateStatus: "getupdatestatus",

    SendRAScursor: "SendRAScursor",
    SendRASviewChange: "SendRASviewChange",
    SendRASconfigChange: "SendRASconfigChange",
    GetRAS: "GetRAS",

    GetDirListing: "GetDirListing",
    GetFileChunk: "GetFileChunk",
    WriteFileChunk: "WriteFileChunk",

    GetServerInfo: "GetServerInfo",
};

GroupArgs = {
    GroupMembers: "groupmembers",
    GroupCommands: "groupcommands",
    GroupWorlds: "groupworlds",
    GroupColor: "Color",
    GroupInherit: "Inherits",
    GroupBuild: "CanBuild",
    GroupInteract: "CanInteract",
    GroupPrefix: "Prefix",
    GroupSuffix: "Suffix",
    GroupDefault: "IsDefault",
};

PermissionFlags = {
    None: 0,
    StopServer: 1, //Also allows kill
    StartServer: 2,
    //RestartServer == 1 + 2
    ConsoleAccess: 4, //Also allows chat, kick, ban, etc
    ModifyUsersAndGroups: 8,
    ModifyMinecraftConfig: 16,
    ModifyFeaturesConfig: 32,
    ModifySettingsConfig: 64,
    ManagePlugins: 128,
    DeleteWorld: 256,
    TakeBackup: 512,
    RestoreBackup: 1024, //Requires DeleteWorld
    DeleteBackup: 2048,
    ModifySchedule: 4096,
    UpdateMinecraft: 8192,
    UpdateMcMyAdmin: 16384, //Requires stop + start
    PerformDiagnostics: 32768,
    FileManager: 65536,
    FileUpload: 131072,
    FileModify: 262144,
    FileUploadExecutable: 524288,
    ModifyMcMyAdminUsers: 1048576
};

UserFlags = {
    CannotChangePassword: 4
};

UpdateEvents = {
    GetStatus: 10,
    GetChat: 20,
    GetBackupStatus: 30,
    GetRestoreStatus: 40,
    GetRAS: 50,
    SetRAS: 60,
};

Icons = {
    Info: "message_info",
    Warning: "message_warn",
    Question: "message_question"
};

ServerStates = {
    NotRunning: 0,
    Starting: 10,
    ServerReady: 20,
    Restarting: 30,
    ShuttingDown: 40,
    Sleeping: 50,
    Error: 100
};

ServerStateStrings = {
    0: Messages.ServerNotRunning,
    10: Messages.ServerStarting,
    20: Messages.ServerReady,
    30: Messages.ServerRestarting,
    40: Messages.ServerShutdown,
    50: Messages.ServerSleeping,
    100: Messages.ServerError
};

ServerStateIcons = {
    0: "status_stop",
    10: "status_wait",
    20: "status_go",
    30: "status_restart",
    40: "status_wait",
    50: "status_sleep",
    100: "status_err"
};

Tasks = {
    ServerStarting: 10,
    ServerStopping: 20,
    ServerRestarting: 30,
    Backup: 40,
    Restore: 50,
    Delete: 60,
    Update: 70
};

Cookies = {
    DisableAnimation: "DISABLEANIM",
    iDevice: "IDEVICE",
    Theme: "THEME",
    UIColor: "UICOLOR",
    SavedUsername: "SAVEUSER",
    SavedPassword: "SAVEPASS",
    SavedToken: "AUTHTOKEN",
};

var UpdateIntervals = new Array();
var RunningTasks = new Array();
var LastTaskID = 0;
var UpdateShown = false;
var SessionID = "";
var Messages;
var ScrollChat = true;
var LoginWithToken = false;
var LastPWGrade = 0;

/*Analytics*/

var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-19277045-11']);
_gaq.push(['_trackPageview']);

(function () {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

/*End Analytics*/

function nopFalse() { return false; }

function checkBrowser() {
    var BasicCSS = false;
    var mobile = false;
    var disableAnimations = false;

    var matchiDevice = new RegExp("i[p|P](hone|ad|od)");
    var iDeviceTest = matchiDevice.exec(navigator.userAgent);

    if (iDeviceTest != null) {
        var iDevice = iDeviceTest[0];
        BasicCSS = true;
        mobile = true;
        disableAnimations = true;

        if (parseBool(getCookie(Cookies.iDevice)) != true) {
            createWarning(Messages.Title_iDevice.format(iDevice), Messages.Message_iDevice.format(iDevice), showAppStore);
        }
    }

    if (navigator.userAgent.match("[a|A]ndroid")) {
        BasicCSS = true;
        mobile = true;
        disableAnimations = true;
    }

    if (navigator.userAgent.match("ZuneWP")) {
        BasicCSS = true;
        mobile = true;
        disableAnimations = true;
    }

    if (navigator.appVersion.indexOf("MSIE") != -1) {
        BasicCSS = true;
        var version = parseFloat(navigator.appVersion.split("MSIE")[1]);
        if (version < 9) {
            createWarning(Messages.Title_UnsupportedBrowser, Messages.Message_UnsupportedBrowser, null);
            //showFatal(Messages.Title_UnsupportedBrowser, Messages.Message_UnsupportedBrowser);
        }
    }

    if (BasicCSS) {
        $("head").append("<link type=\"text/css\" href=\"css/Basic.css\" rel=\"stylesheet\" />");
    }

    if (mobile) {
        $("head").append("<link type=\"text/css\" href=\"css/Mobile.css\" rel=\"stylesheet\" />");
    }

    if (disableAnimations && parseBool(getCookie(Cookies.DisableAnimation)) != true) {
        setCookie(Cookies.DisableAnimation, true);
    }

    getAnim();
}

function showAppStore() {
    setCookie(Cookies.iDevice, true);
    window.open("https://itunes.apple.com/us/app/mcmyadmin-mobile-2/id469794253?mt=8&uo=4&at=11lbeZ");
}

function LoadExtension(name) {
    if (name == "") { return; }

    $("head").append("<script type=\"text/javascript\" src=\"Extensions/{0}/Extension.js\"></script>".format(name));
    var ExtensionInfo = Extensions[name];

    if (ExtensionInfo == null) {
        alert("Invalid extension: '{0}'".format(name));
    } else {
        if (ExtensionInfo.CreateTab == true) {
            $("#sidetabs").append("<a class=\"sidetab\" href=\"#tab_{0}\" id=\"tabhead_{0}\"><img src=\"Extensions/{0}/Icon.png\" alt=\"{1}\" /><span>{1}</span></a>".format(name, ExtensionInfo.TabTitle));

            var sideHeight = $("#sidetabs").height() + 67;

            $("#tasksarea").css("top", sideHeight + "px");

            var newTab = $("<div class=\"tabarea\" id=\"tab_{0}\"><h3>{1}</h3><img src=\"Extensions/{0}/Icon.png\" alt=\"{1}\" class=\"tabimg\"/><div class=\"tabcontents\"></div></div>".format(name, ExtensionInfo.TabTitle));
            newTab.hide();
            $("#tabs").append(newTab);

            $.get("Extensions/{0}/Content.html".format(name), function (data) {
                newTab.find(".tabcontents").html(data);
            });
        }

        ExtensionInfo.Init();
        $("#extlist").append("<li>{0} - {1}</li>".format(ExtensionInfo.Name, ExtensionInfo.Author));
    }
}

function parseBool(value) {
    if (value == null) { return false; }

    if (typeof value == "number") {
        return (parseInt(value) > 0);
    }

    switch (value.toString().toLocaleLowerCase()) {
        case "1":
        case "true":
        case "yes":
        case "on":
            return true;
        default:
            return false;
    }
}

String.prototype.format = function () {
    var args = arguments;
    return this.replace(/{(\d+)}/g, function (match, number) {
        return typeof args[number] != 'undefined' ? args[number] : match;
    });
};

function lostPW() {
    showModal(Messages.Title_LostPW, Messages.Message_LostPW, Icons.Question, hideModal, null);
}

$(function () {
    $("#loginwait").parent().hide();
    $("#sidetabs, #loginerror, #modalbg, #tasksarea").hide();
    $("#selPast, #selTime, #selEveryHour, #eventparam, #selEventTrigger").hide();
    $("#tabs, #tabs .tabarea, .subtabcontainer, #userinfo, #passwdchange").hide();
    $("#currentpluginholder, #currentworldholder, #RASoverlay").hide();

    getLastColor();
    getTheme();

    LoadExtensions(initFrontend);
});

function LoadExtensions(callback) {
    requestData(APICommands.GetExtensions, {}, function (data) {
        if (data != undefined && data.data != undefined) {
            var loadExtList = data.data;
            for (var i in loadExtList) {
                var loadExt = loadExtList[i];
                LoadExtension(loadExt);
            }
        }
        callback();
    });
}

function fixLegacyConfig() {
    if (typeof StatusMaxFails === 'undefined') {
        StatusMaxFails = 30;
    }

    if (typeof MinPassGrade === 'undefined') {
        MinPassGrade = 3;
    }
}

function initFrontend() {
    fixLegacyConfig();

    $.fn.enterPressed = function (callback) {
        this.keypress(function (event) {
            if (event.keyCode == '13') {
                event.preventDefault();
                callback();
            }
        });
    };

    $(".pagehost").text(document.location.host);

    $(".sidetab").mousedown(tabClick);
    $(".sidetab").click(nopFalse);
    $(".subtab").mousedown(subTabClick);
    $(".subtab").click(nopFalse);
    $(".colorsample").click(changeColor);
    $("#setting_local_theme").change(pickTheme);
    $("#setting_local_notransitions").change(setAnim);
    $("#customcolor").unbind("click").click(pickColor);
    $(".userFlag").change(toggleUserFlag);
    $(".userSetting").change(toggleSettingFlag);
    $("#newpwd").keypress(evalPasswordGrade);
    $("#newpwd").change(evalPasswordGrade);
    $("#fileManagerTable").click(fileManagerClick);

    $("#button_startserver").click(function () {
        performAction(APICommands.StartServer);
        RunningTasks[Tasks.ServerStarting] = createNotice(Messages.ServerStarting);
    });

    $("#button_stopserver").click(function () {
        performAction(APICommands.StopServer);
        RunningTasks[Tasks.ServerStopping] = createNotice(Messages.ServerShutdown);
    });

    $("#button_sleepserver").click(function () {
        performAction(APICommands.SleepServer);
    });

    $("#button_restartserver").click(function () {
        performAction(APICommands.RestartServer);
        RunningTasks[Tasks.ServerRestarting] = createTask(Messages.ServerRestartingShort);
    });

    $("#chatEntryBox").keypress(function (event) {
        if (event.keyCode == '13') {
            event.preventDefault();

            var message = $(this).val();

            requestData(APICommands.SendChat, { Message: message }, null);

            $(this).val("");

            if (message[0] == "/") {
                addChatEntry("Server", message, true);
            }
        }
    });

    $(window).resize(resizedWindow);
    resizedWindow();

    $("#chatHistory").mouseenter(function () { ScrollChat = false; });
    $("#chatHistory").mouseleave(function () { ScrollChat = true; });

    $("#newGroupUser").enterPressed(addGroupMemeber);
    $("#newGroupUserButton").click(addGroupMemeber);
    $("#newGroupCommand").enterPressed(addGroupCommand);
    $("#newGroupCommandButton").click(addGroupCommand);
    $("#newGroupName").enterPressed(addGroup);
    $("#newGroupButton").click(addGroup);
    $("#addWorldButton").click(addGroupWorld);
    $("#deleteGroupButton").click(delGroup);
    $("#changeUserPassword").click(changeUserPassword);
    $("#deleteUserButton").click(deleteUser);
    $("#changePasswordCancelButton").click(hidePwChange);
    $("#chancePasswordOKButton").click(pwChangeOk);
    $("#newpwd2").enterPressed(pwChangeOk);
    $("#newUserName").enterPressed(addUser);
    $("#addUserButton").click(addUser);
    $("#getWidgetCode").click(getWidgetCode);
    $("#renameGroupButton").click(renameGroup);
    $("#refreshPlugins").click(refreshPlugins);
    $("#jumptofeatures").click(jumpToFeatures);
    $("#st_2_2").click(getBukgetCategories);
    $("#installPluginButton").click(downloadPlugin);
    $("#worldbackup").change(toggleWorldBackup);

    $("#button_updatemc, #button_updatemc2").click(UpdateMC);
    $("#button_updatemcma").click(UpdateMCMA);

    $("#BukgetSearchQuery")
    .val(Messages.SearchBoxPlugins)
    .addClass("novalue")
    .focus(function () {
        if ($(this).val() == Messages.SearchBoxPlugins) {
            $(this).val("");
            $(this).removeClass("novalue");
        }
    })
    .blur(function () {
        if ($(this).val() == "") {
            $(this).val(Messages.SearchBoxPlugins);
            $(this).addClass("novalue");
        }
    });

    $("#BukgetSearchQuery").enterPressed(searchBukgetPlugins);

    fillTimeSelects();
    ApplyLanguage();
    checkBrowser();
    getProvider();
    setupFileDnD();

    if (document.location.protocol == "file:") {
        showFatal(Messages.ErrorIncorrectUsage, Messages.ErrorIncorrectUsageText);
        return;
    }

    checkSavedLogin();

    $("#loginusername").focus();
}

function resizedWindow(event) {
    var newHeight = $(window).height() - 214;
    $("#chatHistory").css('height', newHeight + "px");
    $("#chatNames").css('height', newHeight + "px");
}

function jumpToFeatures() {
    $("#st_5").mousedown();
    setTimeout(function () {
        $("#st_1_4").mousedown();
        setTimeout(function () {
            $('html,body').animate({ scrollTop: 500 }, 750, function () {
                $("#exportconfigrow").animate({ backgroundColor: "#FFE97F" }, 750, function () {
                    $("#exportconfigrow").animate({ backgroundColor: "transparent" }, 750, function () {
                        $("#exportconfigrow").css("background-color", "transparent");
                    });
                });
            });
        }, 750);
    }, 500);
    return false;
}

function checkSavedLogin() {
    var username = getCookie(Cookies.SavedUsername);
    if (username != null && username.length > 0) {
        $("#loginusername").val(username);
        $("#rememberLogin").prop("checked", true);
        doLogin(true);
    }
}

function clearTasks() {
    $("#tasksarea .task").remove();
    $("#tasksarea").hide('drop', { direction: 'left' });
    RunningTasks = new Array();
    LastTaskID = 0;
}

function endTask(taskId) {
    var eId = "#task_" + taskId;

    if ($(eId).length == 1) {
        if ($("#tasksarea .task").length == 1) {
            $("#tasksarea").hide('drop', { direction: 'left' }, function () {
                $(eId).remove();
                updateNoticeTitles();
            });
        }
        else {
            $(eId).hide('drop', { direction: 'left' }, function () {
                $(eId).remove();
                updateNoticeTitles();
            });
        }
    }
}

function backupUploadFinished() {
    getBackupList();
    showModal(Messages.Title_UploadOK, Messages.Message_BackupUploaded, Icons.Info, hideModal, null);
}

function setTaskStatus(taskId, percentage) {
    var eId = "#task_" + taskId;

    if ($(eId).length == 1) {
        $(eId + " .progressbarslider").css("width", percentage + "%");
    }
}

function updateNoticeTitles() {
    setTimeout(function () {
        var notifyCount = $("#tasksarea .task_warn").length;
        if (notifyCount) {
            $("#noticestitle").show();
            $("#noticestitle").text(Messages.Notifications.format(notifyCount));
        } else {
            $("#noticestitle").hide();
        }

        var taskCount = $("#tasksarea .task_activity").length;
        if (taskCount) {
            $("#runtasktitle").show();
            $("#runtasktitle").text(Messages.RunningTasks.format(taskCount));
        } else {
            $("#runtasktitle").hide();
        }
    }, 500);
}

function createNotice(title) {
    var taskId = LastTaskID;
    var eId = "task_" + LastTaskID;
    var taskElement = "<div class=\"task task_activity\" id=\"" + eId + "\">" +
        "<img src=\"Images/loadspin_tiny.gif\" alt=\"Progress\" class=\"loadspin_tiny inline\"/>" +
        "<div class=\"noticeline\">" + title + "</div>" +
        "</div>";
    $("#runtasktitle").after(taskElement);

    if ($("#tasksarea").is(":hidden")) {
        $("#tasksarea").show('drop', { direction: 'left' });
    }
    else {
        $("#tasksarea .task:first").show('drop', { direction: 'left' });
    }

    LastTaskID++;

    updateNoticeTitles();

    return (taskId);
}

function createWarning(title, message, onDismiss, autoDismiss) {
    var taskId = LastTaskID;
    var eId = "task_" + LastTaskID;
    //var taskElement = "<div class=\"task task_warn\" id=\"{0}\" onclick=\"endTask({1});\"><div class='title'>{2}</div><div>{3}</div></div>".format(eId, taskId, title, message);

    var taskElement = $("<div class=\"task task_warn\" id=\"{0}\"><div class='title'>{1}</div><div>{2}</div></div>".format(eId, title, message));

    taskElement.click(function () {
        endTask(taskId);
        if (onDismiss != null) {
            onDismiss();
        }
    });

    if (autoDismiss > 0) {
        setTimeout(function () {
            taskElement.click();
        }, autoDismiss);
    }

    $("#noticestitle").after(taskElement);

    if ($("#tasksarea").is(":hidden")) {
        $("#tasksarea").show('drop', { direction: 'left' });
    }
    else {
        $("#tasksarea .task:first").show('drop', { direction: 'left' });
    }

    LastTaskID++;

    updateNoticeTitles();

    return (taskId);
}

function createTask(title) {
    var taskId = LastTaskID;
    var eId = "task_" + LastTaskID;
    var taskElement = "<div class=\"task task_activity\" id=\"" + eId + "\">" +
        "<h5 class=\"notopmargin\">" + title + "</h5>" +
        "<img src=\"Images/loadspin_tiny.gif\" alt=\"Progress\" class=\"loadspin_tiny\"/>" +
        "<div class=\"progressbar\">" +
            "<div class=\"progressbarslider\"></div>" +
        "</div></div>";

    $("#runtasktitle").after(taskElement);

    if ($("#tasksarea").is(":hidden")) {
        $("#tasksarea").show('drop', { direction: 'left' });
    }
    else {
        $("#tasksarea .task:first").show('drop', { direction: 'left' });
    }

    LastTaskID++;

    updateNoticeTitles();

    return (taskId);
}

function logDebug(message) {

}

function showFatal(title, text) {
    $.fx.off = true;
    $("#modalbg").removeClass("modalnormal").addClass("modalfatal");
    showModal(title, text, "message_error", null, null);
}

function getWidgetCode() {
    var widgetCode = "<script type=\"text/javascript\" src=\"{0}//{1}/js/widget.js\"></script>".format(document.location.protocol, document.location.host);
    prompt(Messages.Title_WidgetCopy, widgetCode);
}

function showModal(title, text, iconClass, okButton, cancelButton, retryButton) //, okText, cancelText, retryText)
{
    $(".modalpanel").stop();

    $("#modaltitle").text(title);
    $("#modalmessage").html(text);
    $("#message_icon").attr("class", iconClass);

    $(".modalpanel").css("transform-origin", "center top");
    $(".modalpanel").css("transform", "perspective(1000px) rotateX(90deg)");

    if (okButton == null && cancelButton == null) {
        $("#modalbuttons").hide();
    }
    else {
        $("#modalbuttons").show();
    }

    $("#modalok").unbind("click");
    $("#modalcancel").unbind("click");

    if (okButton == null) {
        $("#modalok").hide();
        $("#modalok").click(nopFalse);
    }
    else {
        $("#modalok").show();
        $("#modalok").click(okButton);
    }

    if (cancelButton == null) {
        $("#modalcancel").hide();
        $("#modalcancel").click(nopFalse);
    }
    else {
        $("#modalcancel").show();
        $("#modalcancel").click(cancelButton);
    }

    if (retryButton == null) {
        $("#modalretry").hide();
        $("#modalretry").click(nopFalse);
    }
    else {
        $("#modalretry").show();
        $("#modalretry").click(retryButton);
    }

    $("#modalbg").fadeIn();

    $(".modalpanel").animate({ rotateY: 90 }, {
        step: function (now) {
            $(this).css('transform', 'perspective(1000px) rotateX(' + (90 - now) + 'deg)');
        },
        duration: 1000,
    });
}

function featureUnavailable() {
    showModal(Messages.Title_FeatureUnavailable, Messages.Message_FeatureUnavailable, Icons.Info, hideModal, null);
}

function hideModal() {
    $("#modalbg").fadeOut();
}

function ApplyLanguage() {
    $("div, span, p, h1, h2, h3, h4, h5, a, td, option, label").each(function (index) {
        var message = $(this).text();

        if (LocalizedText[message]) {
            if ($(this).children().length == 0) {
                $(this).html(LocalizedText[message]);
            }
        }
    });

    $("input").each(function () {
        var message = $(this).val();

        if (LocalizedText[message]) {
            $(this).val(LocalizedText[message]);
        }
    });
}

function EnableTranslateMode() {
    $("div, span, p, h1, h2, h3, h4, h5, a, td, label").mousedown(function (event) {
        if (event.which == 3 && $(this).children().length == 0) {
            var oldText = $(this).text();
            var newText = prompt("Enter replacement text for '{0}'".format(oldText), oldText);
            if (newText != null && newText != oldText) {
                LocalizedText[oldText] = newText;
                $(this).text(newText);
                ApplyLanguage();
            }
        }
    });

    $("input").mousedown(function (event) {
        if (event.which == 3 && $(this).children().length == 0) {
            var oldText = $(this).val();
            var newText = prompt("Enter replacement text for '{0}'".format(oldText), oldText);
            if (newText != null && newText != oldText) {
                LocalizedText[oldText] = newText;
                $(this).val(newText);
                ApplyLanguage();
            }
        }
    });

    alert("Right click on text to replace its value. Text that is dynamically created from values must be edited in the language file directly.");
}

function getLastColor() {
    var color = getCookie(Cookies.UIColor);
    if (color != null) {
        $("body").css('background-color', color);
    }
}

function getTheme() {
    var theme = getCookie(Cookies.Theme);

    $("#setting_local_theme").val(theme);

    switch (theme) {
        case "DEFAULT":
        case "CLASSIC":
            $("#styleSheet").attr("href", "css/McMyAdmin.css");
            break;
        case "ALTERNATE":
            $("#styleSheet").attr("href", "css/McMyAdmin_Alternate.css");
            break;
        case "METRO":
            $("#styleSheet").attr("href", "css/McMyAdmin_Metro.css");
            break;
        case "SLICK":
        default:
            $("#styleSheet").attr("href", "css/McMyAdmin_Slick.css");
            break;
    }
}

function getAnim() {
    var noanim = getCookie(Cookies.DisableAnimation);
    if (parseBool(noanim) == true) {
        $.fx.off = true;
    }
    else {
        $.fx.off = false;
    }
}

function setAnim() {
    var animValue = parseBool($("$setting_local_notransitions"));
    setCookie(Cookies.DisableAnimation, animValue);
}

function changeColor() {
    var newColor = $(this).css('background-color');
    $("body").animate({ backgroundColor: newColor }, 2000);
    setCookie(Cookies.UIColor, newColor);
}

function pickTheme() {
    var useTheme = $("#setting_local_theme").val();

    setCookie(Cookies.Theme, useTheme);

    switch (useTheme) {
        case "CLASSIC":
        case "DEFAULT":
            setCookie(Cookies.UIColor, "#3F647F");
            break;
        case "ALTERNATE":
            setCookie(Cookies.UIColor, "#C4C2B8");
            break;
        case "METRO":
            setCookie(Cookies.UIColor, "#FFFFFF");
            break;
        case "SLICK":
        default:
            setCookie(Cookies.UIColor, "#404040");
            break;
    }

    getTheme();
    getLastColor();
}

function pickColor() {
    var newColor = prompt(Messages.Text_PickColor);
    if (newColor != null && newColor != "") {
        $("body").animate({ backgroundColor: "#" + newColor }, 2000);
        setCookie(Cookies.UIColor, "#" + newColor);
    }
}

function subTabClick() {
    var thiselement = $(this);
    var thisid = thiselement.attr('id');

    thiselement.parent().children(".picked").removeClass("picked");
    thiselement.addClass("picked");

    var nextTab = thiselement.attr('href');
    thiselement.parent().siblings(".subtabcontainer").hide();
    $(nextTab).show();

    if (RASserver) { requestData(APICommands.SendRASviewChange, { view: thisid }, null); }

    return false;
}

function tabClick() {
    var thiselement = $(this);
    var thisid = thiselement.attr('id');

    thiselement.parent().children(".picked").removeClass("picked");
    thiselement.addClass("picked");

    var nexttab = thiselement.attr('href');
    var visibletab = "#" + $("#tabs .tabarea:visible:first").attr('id');

    if (visibletab != nexttab) {
        $("#tabs .tabarea:visible").hide('drop', { direction: 'right' }, 250, function () {
            $(nexttab).fadeIn(250);
            $(nexttab).find(".subtabhead a:visible").first().mousedown();
        });
    }

    swapText("#bgtext", thiselement.text(), false);

    if (RASserver) { requestData(APICommands.SendRASviewChange, { view: thisid }, null); }

    return (false);
}

function uiReady() {
    swapText("#LoginMessage", Messages.LoginDone, true, true);

    hideSvButtons();
    populateGraph();

    getSchedule();
    getBackupList();
    getPluginList();
    getVersions();
    getListing();
    getWorlds(function () {
        getGroups(getConfiguration);
    });

    CategoriesFetched = false;

    if ((userPermissions & PermissionFlags.ModifyMcMyAdminUsers) > 0) {
        getUsers();
    }

    startUpdates();

    $("#newuserpass").val("");
    $("#newuserpass_confirm").val("");

    setTimeout(function () {
        setupAuthMask();
        $("#CCbrand").fadeOut();
        $("#loginwait").parent().hide('drop', { direction: direction }, function () {
            $("#loggedinas").text(Messages.LoggedinAs.format($("#loginusername").val()));
            $("#userinfo").fadeIn();
            $("#tabs .tabarea:first, #tab_config_gamesettings, #tab_about_info").show();
            $("#tab_plugins_manage").show();
            $("#st_0").mousedown();
            $("#sidetabs").show('drop', { direction: 'left' });
            $("#welcomescreen").fadeOut(function () { $("#tabs").fadeIn(); });
            swapText("#bgtext", Messages.Status, false);
            getTip();
            showFirstTime();
        });
    }, 1000);

}

function weakPassword() {
    showModal(Messages.Title_MustChange, Messages.Message_MustChange, Icons.Warning, function () {
        hideModal();
        showChangePassword(true);
    }, null);
}

function showFirstTime() {
    if (parseBool(oldValues["mcmyadmin.firststart"]) == true) {
        setConfigVal("mcmyadmin.firststart", "0");
        showModal(Messages.Title_Welcome, Messages.Message_Welcome, Icons.Info, function () {
            $("#st_5").mousedown();
            hideModal();
        }, null);
    }
}

function getTip() {
    requestData(APICommands.GetTipOfDay, {}, function (data) {
        if (data) {
            createWarning(Messages.TipOfTheDay, data.tip, null, 5000);
        }
    });
}

function populateGraph() {
    for (var i = 0; i < 64; i++) {
        $("#CPUHistoryGraph").append("<div class=\"graphBar\" style=\"height:0px;\"></div>");
        $("#MemoryHistoryGraph").append("<div class=\"graphBar\" style=\"height:0px;\"></div>");
    }
}

function getPercentAsColorClass(percent) {
    if (percent < 33) { return "percent_low"; }
    if (percent < 66) { return "percent_med"; }
    return "percent_high";
}

function addGraphEntries(cpu, ram) {
    $("#CPUHistoryGraph").children(".graphBar").first().remove();
    $("#MemoryHistoryGraph").children(".graphBar").first().remove();

    var cpucolclass = getPercentAsColorClass(cpu);
    var ramcolclass = getPercentAsColorClass(ram);

    $("#CPUHistoryGraph").append("<div class=\"graphBar {1}\" style=\"height:{0}px;\"></div>".format(cpu, cpucolclass));
    $("#MemoryHistoryGraph").append("<div class=\"graphBar {1}\" style=\"height:{0}px;\"></div>".format(ram, ramcolclass));
}

var DataSource = "data.json";

function performAction(requestType) {
    requestData(requestType, {}, $.noop);
}

var PendingRequests = 0;
var RASclient = false;
var RASserver = false;

function requestData(requestType, data, callback, usePOST) {
    //if (RASclient && requestType != APICommands.GetRAS) { return; }

    data = (data) ? data : new Array();
    callback = (callback) ? callback : $.noop;
    var post = (usePOST != undefined) ? usePOST : false;

    data["req"] = requestType;
    data["MCMASESSIONID"] = SessionID;

    logDebug("Outgoing request: " + requestType);

    PendingRequests++;

    $("#queueSize").text(PendingRequests);

    $.ajax({
        type: (post) ? "POST" : "GET",
        url: DataSource,
        data: data,
        dataType: 'json',
        timeout: RequestTimeout,
        success: function (response) {
            PendingRequests--;
            $("#queueSize").text(PendingRequests);
            logDebug("Completed request: " + requestType);
            if (response.status == 500) {
                var title = Messages.RequestErrorTitle;

                if (typeof response.errortitle !== "undefined") {
                    title = response.errortitle;
                }

                showModal(title, response.errormessage, Icons.Warning, hideModal, null);
            }
            callback(response);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            if (parseInt(jqXHR.status) == 401) {
                stopUpdates();
                showModal(Messages.UserLoggedOutTitle, Messages.UserLoggedOutMessage, Icons.Warning, function () {
                    hideModal();
                    doLogout();
                }, null);
            }
            PendingRequests--;
            logDebug("Timed out request: " + requestType);
            $("#queueSize").text(PendingRequests);
            callback(null);
        }
    });
}

var userPermissions = 0;
var userFlags = 0;

function loginCallback(data) {
    $("#loginpassword").val("");

    if (data) {
        if (parseInt(data.status) == 429) {
            hideLoginWaiting(false, Messages.TooManyBadLogins);
            userPermissions = 0;
            userFlags = 0;
        }
        else {
            if (data.success == true) {
                if ($("#rememberLogin").is(":checked")) {
                    setCookie(Cookies.SavedUsername, $("#loginusername").val());
                    setCookie(Cookies.SavedToken, data.RDTOKEN);
                }

                userPermissions = data.authmask;
                userFlags = data.usermask;
                SessionID = data.MCMASESSIONID;
            }
            else {
                setCookie(Cookies.SavedUsername, "");
                setCookie(Cookies.SavedToken, "");
            }

            if (LoginWithToken) {
                hideLoginWaiting(data.success, Messages.LoginExpired);
            }
            else {
                hideLoginWaiting(data.success, Messages.IncorrectLogin);
            }
        }
    }
    else {
        hideLoginWaiting(false, Messages.ServerContactErr.format(document.location.host));
        userPermissions = 0;
        userFlags = 0;
    }
}

function setupAuthMask() {
    for (var i = 1; i < 2097152; i *= 2) {
        var flag = (userPermissions & i);
        var objClassShow = ".auth_{0}:not(.tabarea, .subtabcontainer, #tab_status.button)".format(i);
        var objClassHide = ".auth_{0}".format(i);

        if (flag == 0) {
            $(objClassHide).hide();
        } else {
            $(objClassShow).show();
        }
    }

    if (userFlags & UserFlags.CannotChangePassword) {
        $("#changePasswordArea").hide();
    } else {
        $("#changePasswordArea").show();
    }
}

function showLoginWaiting(callback) {
    $("#loginscreen").parent().hide('drop', { direction: 'right' }, 250, function () {
        $("#loginwait").parent().show('drop', { direction: 'left' }, 250, callback);
    });
}

function hideLoginWaiting(done, message) {
    direction = (done) ? 'right' : 'left';

    if (done) {
        uiReady();
    }
    else {
        $("#loginwait").parent().hide('drop', { direction: direction }, function () {
            if (message) {
                $("#loginerror").html(message);
                $("#loginerror").show();
            }
            else {
                $("#loginerror").hide();
            }

            $("#loginscreen").parent().show('drop', { direction: 'right' });
        });
    }
}

function loginSlow() {
    swapText("#LoginMessage", Messages.LoginSlow, true, true);
}

function swapText(element, text, useParent, swipe) {
    var moveElement = (useParent == true) ? $(element).parent() : $(element);

    if ($(element).text() == text) { return; }

    if (swipe) {
        moveElement.hide('drop', { direction: 'down' }, 150, function () {
            $(element).text(text);
            moveElement.show('drop', { direction: 'up' }, 150);
        });
        return;
    }

    moveElement.fadeOut(function () {
        $(element).text(text);
        moveElement.fadeIn();
    });
}

function doLogout() {
    stopUpdates();
    clearTasks();
    hidePwChange();

    setCookie(Cookies.SavedUsername, "");
    setCookie(Cookies.SavedToken, "");

    performAction(APICommands.Logout);

    $("#loginusername").val("");
    $("#loginpassword").val("");
    $("#rememberLogin").prop("checked", false);
    $("#userinfo").fadeOut();
    $("#tabs .tabarea").hide();
    $("#sidetabs").hide('drop', { direction: 'left' });
    $("#tabs").fadeOut(function () {
        $("#welcomescreen").fadeIn();
        $("#loginscreen").parent().show('drop', { direction: 'right' });
        $("#CPUHistoryGraph").empty();
        $("#MemoryHistoryGraph").empty();
    });
    $(".reg_versioninfo, .reg_owner").text("");
    $("#CCbrand").fadeIn();
    swapText("#bgtext", Messages.Welcome, false);

}

function doLogin(token) {
    LoginWithToken = token;
    setCookie(Cookies.SavedPassword, "");
    var Username = (token) ? getCookie(Cookies.SavedUsername) : $("#loginusername").val();
    var Password = (token) ? "" : $("#loginpassword").val();
    var Token = (token) ? getCookie(Cookies.SavedToken) : "";

    if (token != true) {
        LastPWGrade = getPasswordStrength(Password);
    }
    else {
        LastPWGrade = 999;
    }

    $("#LoginMessage").text(Messages.LoginMessage);

    showLoginWaiting(function () {
        setTimeout(loginSlow, 5000);
        requestData(APICommands.Login, { Username: Username, Password: Password, Token: Token }, loginCallback);
    });
}

function startUpdates() {
    UpdateIntervals[UpdateEvents.GetStatus] = setInterval(getStatus, StatusUpdateInterval);
    UpdateIntervals[UpdateEvents.GetChat] = setInterval(getChat, StatusUpdateInterval);
}

function stopUpdates() {
    clearInterval(UpdateIntervals[UpdateEvents.GetStatus]);
    clearInterval(UpdateIntervals[UpdateEvents.GetChat]);
}

function startRASclient() {
    $("#RASoverlay").show();
    UpdateIntervals[UpdateEvents.GetRAS] = setInterval(getRAS, 500);
    createWarning("Remote Assistance Guest", "You are currently joined to a remote-assistance session. Click the button in the bottom-left to end the session.");
    RASclient = true;
}

function stopRASclient() {
    $("#RASoverlay").hide();
    clearInterval(UpdateIntervals[UpdateEvents.GetRAS]);
    RASclient = false;
    doLogout();
}

var curX = 0;
var curY = 0;

function startRASserver() {
    UpdateIntervals[UpdateEvents.SetRAS] = setInterval(setRAS, 500);
    $(document).mousemove(storeCursorPos);
    createWarning("Remote Assistance Host", "You are currently a remote assistance host. Click here to end the session", stopRASserver);
    RASserver = true;
}

function stopRASserver() {
    clearInterval(UpdateIntervals[UpdateEvents.SetRAS]);
    $(document).unbind("mousemove");
    RASserver = false;
}

function storeCursorPos(e) {
    curX = e.pageX;
    curY = e.pageY;
}

function setRAS() {
    requestData(APICommands.SendRAScursor, { x: curX, y: curY }, null);
}

function getRAS() {
    requestData(APICommands.GetRAS, {}, function (data) {
        $("#RAScursor").animate({ top: data.curY + "px", left: data.curX + "px" }, 150);

        if (data.view != "") {
            $("#" + data.view).mousedown();
        }

        if (data.config != "") {
            var element = "#" + settingsArray[data.config.Key];

            if ($(element) != null) {
                $(element).val(data.config.Value);
            }
        }
    });
}

function addChatEntry(name, message, time, isChat) {
    var dateString = parseDate(time).toLocaleTimeString();

    var newLine = $("<div class=\"chatEntry\"></div>");
    newLine.data("isChat", parseBool(isChat));

    var chatBody = $("<div class=\"chatBody\"></div>");
    chatBody.append($("<div class=\"chatTimestamp\"></div>").text(dateString));
    chatBody.append($("<div class=\"chatNick\"></div>").text(" " + name + ": "));
    chatBody.append($("<div class=\"chatMessage\"></div>").text(message));

    newLine.append(chatBody);
    newLine.children("div.chatTimestamp:first").text(dateString);
    newLine.children("div.chatNick:first").text();
    newLine.children("div.chatMessage:first").text(message);

    if ($("#chatHistory").children("div").size() > 200) {
        $("#chatHistory").children("div").first().remove();
    }

    $("#chatHistory").append(newLine);

    var hist = document.getElementById("chatHistory");

    if (ScrollChat) {
        hist.scrollTop = hist.scrollHeight;
    }
}

var LastChatTimestamp = -1;

function getChat() {
    requestData(APICommands.GetChat, { Since: LastChatTimestamp }, function (data) {
        if (data) {
            var chatData = data.chatdata;

            for (var i in chatData) {
                var line = chatData[i];

                addChatEntry(line.user, line.message, line.time, line.isChat);
            }

            LastChatTimestamp = data.timestamp;
        }
    });
}

function getDate() {
    var theDate = new Date();
    var day = theDate.getDate();
    day = (day < 10) ? "0" + day : day;
    var month = theDate.getMonth() + 1;
    month = (month < 10) ? "0" + month : month;
    var date = theDate.getFullYear() + "-" + month + "-" + day + " " + theDate.toLocaleTimeString();
    return (date);
}

function getTimestamp() {
    var theDate = new Date();
    var date = theDate.toLocaleTimeString();
    return (date);
}

function hideSvButtons() {
    $("#button_startserver").hide();
    $("#button_stopserver").hide();
    $("#button_killserver").hide();
    $("#button_restartserver").hide();
    $("#button_sleepserver").hide();
}

function showButtons(status) {
    hideSvButtons();
    switch (status) {
        case ServerStates.Error:
        case ServerStates.NotRunning:
            $("#button_startserver").show();

            endTask(RunningTasks[Tasks.ServerStopping]);
            endTask(RunningTasks[Tasks.ServerStarting]);

            break;
        case ServerStates.Starting:
            $("#button_stopserver").show();
            $("#button_restartserver").show();

            setTaskStatus(RunningTasks[Tasks.ServerRestarting], 50);

            break;
        case ServerStates.Sleeping:
            $("#button_stopserver").show(); break;
            break;
        case ServerStates.ServerReady:
            $("#button_stopserver").show();
            $("#button_sleepserver").show();
            $("#button_restartserver").show();

            setTaskStatus(RunningTasks[Tasks.ServerRestarting], 100);
            endTask(RunningTasks[Tasks.ServerStarting]);
            endTask(RunningTasks[Tasks.ServerRestarting]);

            break;
        case ServerStates.Restarting:
            $("#button_stopserver").show();
            $("#button_killserver").show(); break;
        case ServerStates.ShuttingDown:
            $("#button_killserver").show(); break;
    }
}

var prevstate = -1;

var statusFails = 0;

var OldPlayers = new Array();

var OnlineUsers;

function getStatus() {
    requestData(APICommands.GetStatus, {}, function (data) {
        $("#status_lastupdate").text(getDate());

        if (data == null) {
            $("#status_statetext").html(Messages.ServerWaitBackend.format(statusFails, StatusMaxFails));
            $("#status_icon").attr("class", ServerStateIcons[100]);

            prevstate = -1;
            statusFails++;

            if (statusFails > StatusMaxFails) {
                stopUpdates();
                showModal(Messages.ErrorCommunicatingTitle, Messages.ErrorCommunicatingText, Icons.Warning, function () {
                    doLogout();
                    hideModal();
                }, null);
            }
        }
        else {

            statusFails = 0;
            var memUsagePercent = Math.floor((data.ram / data.maxram) * 100);

            if (data.state != ServerStates.NotRunning) {
                addGraphEntries(data.cpuusage, memUsagePercent);
            }

            $("#status_onlineplayers").text(data.users + " / " + data.maxusers);
            $("#status_servertime").text(data.time);
            $("#status_CPUusage").text(data.cpuusage + "%");
            $("#status_RAMusage").text(memUsagePercent + "%");
            $("#status_ramMB").text(Messages.RAMUsage.format(data.ram, data.maxram));
            $("#status_miniCPUgraph").css("width", data.cpuusage);
            $("#status_miniRAMgraph").css("width", memUsagePercent);

            if (data.state == ServerStates.ServerReady) {
                $("#status_uptime").text(Messages.Text_Uptime.format(data.uptime.Days, data.uptime.Hours, data.uptime.Minutes));
            }
            else {
                $("#status_uptime").text("");
            }

            var state = (data.failed == true) ? 100 : data.state;

            $("#chatNames").empty();

            OnlineUsers = data.userinfo;

            for (var i in OnlineUsers) {
                var user = OnlineUsers[i];

                $("#chatNames").append("<div class=\"chatName\">" + user.Name + "</div>");
            }

            if (state != prevstate) {
                $("#status_statetext").text(ServerStateStrings[state]);
                $("#status_icon").attr("class", ServerStateIcons[state]);

                showButtons(state);

                prevstate = state;

                if (data.failmsg === "EULA")
                {
                    showModal("Minecraft Server EULA", "You must accept the Mojang EULA before you may run the Minecraft server.<br/><br/>Please read the <a href='https://account.mojang.com/documents/minecraft_eula'>Minecraft End User Licence Agreement</a> and ensure that you agree to it.<br/><br/>By clicking 'OK', you indicate that you agree to the linked terms and conditions.<br/>After accepting you may start the Minecraft server.", Icons.Warning, function () {
                        setConfigVal("eula", "true");
                        hideModal();
                        performAction(APICommands.StartServer);
                        RunningTasks[Tasks.ServerStarting] = createNotice(Messages.ServerStarting);
                        
                    }, hideModal, null);
                }
            }
        }
    });
}

function getProvider() {
    requestData(APICommands.GetServerInfo, {}, function (data) {
        if (data.edition == "Enterprise") {
            $("#provby").html(Messages.ProvidedBy.format(data.provider.Name, data.provider.URL));
        }
    });
}

function evalPasswordGrade() {
    var pw = $("#newpwd").val();
    var grade = getPasswordStrength(pw);
    var gradeClass = getGradeAsColorClass(grade);
    var width = 16 * grade;
    $("#pwgradecolor").attr("class", gradeClass);
    $("#pwgradecolor").css("width", width + "px");
}

function getGradeAsColorClass(grade) {
    if (grade > 5) { return "percent_low"; }
    if (grade > 3) { return "percent_med"; }
    return "percent_high";
}

var commonPasswords = ["redstonehost", "123456", "password", "12345678", "1234", "pussy", "12345", "dragon", "qwerty", "696969", "mustang", "letmein", "baseball", "master", "michael", "football", "shadow", "monkey", "abc123", "pass", "fuckme", "6969", "jordan", "harley", "ranger", "iwantu", "jennifer", "hunter", "fuck", "2000", "test", "batman", "trustno1", "thomas", "tigger", "robert", "access", "love", "buster", "1234567", "soccer", "hockey", "killer", "george", "sexy", "andrew", "charlie", "superman", "asshole", "fuckyou", "dallas", "jessica", "panties", "pepper", "1111", "austin", "william", "daniel", "golfer", "summer", "heather", "hammer", "yankees", "joshua", "maggie", "biteme", "enter", "ashley", "thunder", "cowboy", "silver", "richard", "fucker", "orange", "merlin", "michelle", "corvette", "bigdog", "cheese", "matthew", "121212", "patrick", "martin", "freedom", "ginger", "blowjob", "nicole", "sparky", "yellow", "camaro", "secret", "dick", "falcon", "taylor", "111111", "131313", "123123", "bitch", "hello", "scooter", "please", "porsche", "guitar", "chelsea", "black", "diamond", "nascar", "jackson", "cameron", "654321", "computer", "amanda", "wizard", "xxxxxxxx", "money", "phoenix", "mickey", "bailey", "knight", "iceman", "tigers", "purple", "andrea", "horny", "dakota", "aaaaaa", "player", "sunshine", "morgan", "starwars", "boomer", "cowboys", "edward", "charles", "girls", "booboo", "coffee", "xxxxxx", "bulldog", "ncc1701", "rabbit", "peanut", "john", "johnny", "gandalf", "spanky", "winter", "brandy", "compaq", "carlos", "tennis", "james", "mike", "brandon", "fender", "anthony", "blowme", "ferrari", "cookie", "chicken", "maverick", "chicago", "joseph", "diablo", "sexsex", "hardcore", "666666", "willie", "welcome", "chris", "panther", "yamaha", "justin", "banana", "driver", "marine", "angels", "fishing", "david", "maddog", "hooters", "wilson", "butthead", "dennis", "fucking", "captain", "bigdick", "chester", "smokey", "xavier", "steven", "viking", "snoopy", "blue", "eagles", "winner", "samantha", "house", "miller", "flower", "jack", "firebird", "butter", "united", "turtle", "steelers", "tiffany", "zxcvbn", "tomcat", "golf", "bond007", "bear", "tiger", "doctor", "gateway", "gators", "angel", "junior", "thx1138", "porno", "badboy", "debbie", "spider", "melissa", "booger", "1212", "flyers", "fish", "porn", "matrix", "teens", "scooby", "jason", "walter", "cumshot", "boston", "braves", "yankee", "lover", "barney", "victor", "tucker", "princess", "mercedes", "5150", "doggie", "zzzzzz", "gunner", "horney", "bubba", "2112", "fred", "johnson", "xxxxx", "tits", "member", "boobs", "donald", "bigdaddy", "bronco", "penis", "voyager", "rangers", "birdie", "trouble", "white", "topgun", "bigtits", "bitches", "green", "super", "qazwsx", "magic", "lakers", "rachel", "slayer", "scott", "2222", "asdf", "video", "london", "7777", "marlboro", "srinivas", "internet", "action", "carter", "jasper", "monster", "teresa", "jeremy", "11111111", "bill", "crystal", "peter", "pussies", "cock", "beer", "rocket", "theman", "oliver", "prince", "beach", "amateur", "7777777", "muffin", "redsox", "star", "testing", "shannon", "murphy", "frank", "hannah", "dave", "eagle1", "11111", "mother", "nathan", "raiders", "steve", "forever", "angela", "viper", "ou812", "jake", "lovers", "suckit", "gregory", "buddy", "whatever", "young", "nicholas", "lucky", "helpme", "jackie", "monica", "midnight", "college", "baby", "cunt", "brian", "mark", "startrek", "sierra", "leather", "232323", "4444", "beavis", "bigcock", "happy", "sophie", "ladies", "naughty", "giants", "booty", "blonde", "fucked", "golden", "0", "fire", "sandra", "pookie", "packers", "einstein", "dolphins", "0", "chevy", "winston", "warrior", "sammy", "slut", "8675309", "zxcvbnm", "nipples", "power", "victoria", "asdfgh", "vagina", "toyota", "travis", "hotdog", "paris", "rock", "xxxx", "extreme", "redskins", "erotic", "dirty", "ford", "freddy", "arsenal", "access14", "wolf", "nipple", "iloveyou", "alex", "florida", "eric", "legend", "movie", "success", "rosebud", "jaguar", "great", "cool", "cooper", "1313", "scorpio", "mountain", "madison", "987654", "brazil", "lauren", "japan", "naked", "squirt", "stars", "apple", "alexis", "aaaa", "bonnie", "peaches", "jasmine", "kevin", "matt", "qwertyui", "danielle", "beaver", "4321", "4128", "runner", "swimming", "dolphin", "gordon", "casper", "stupid", "shit", "saturn", "gemini", "apples", "august", "3333", "canada", "blazer", "cumming", "hunting", "kitty", "rainbow", "112233", "arthur", "cream", "calvin", "shaved", "surfer", "samson", "kelly", "paul", "mine", "king", "racing", "5555", "eagle", "hentai", "newyork", "little", "redwings", "smith", "sticky", "cocacola", "animal", "broncos", "private", "skippy", "marvin", "blondes", "enjoy", "girl", "apollo", "parker", "qwert", "time", "sydney", "women", "voodoo", "magnum", "juice", "abgrtyu", "777777", "dreams", "maxwell", "music", "rush2112", "russia", "scorpion", "rebecca", "tester", "mistress", "phantom", "billy", "6666", "albert", "foobar"];

function getPasswordStrength(password) {
    var grade = 0;
    grade += (password.match("[A-Z]") != null) ? 1 : 0;
    grade += (password.match("[a-z]") != null) ? 1 : 0;
    grade += (password.match("[0-9]") != null) ? 1 : 0;
    grade += (password.match("[^a-zA-Z0-9]") != null) ? 1 : 0;
    grade += (password.length > 7);
    grade += (password.length > 9);
    grade += (password.length > 11);

    if (commonPasswords.indexOf(password.toLocaleLowerCase()) > -1) {
        grade = 0;
    }

    return (grade);
}

var latestMC = "";

function getVersions() {
    if (typeof (UpdateData) !== 'undefined') {
        $(".reg_latestversion").text(UpdateData.LatestMCMA);
        $(".ver_latestbukkit").text(UpdateData.LatestMinecraftBukkitCompat);
    }

    requestData(APICommands.GetVersions, {}, function (data) {
        if (data) {
            latestMC = data.mclatest.release;
            $(".ver_latestoffical").text(data.mclatest.release);
            $(".reg_versioninfo").text(data.backend + " " + data.edition);
            $(".ver_minecraft").text(data.mc);

            if (data.beta == true) {
                createWarning("McMyAdmin Beta Installation", "You are running a beta version of McMyAdmin, which may have bugs or cause data loss. Use at your own risk, and please report any bugs to the forums or to PhonicUK directly on IRC.", showUpdates);
            }

            if (data.edition != "Personal") {
                $("#licencearea").hide();
            } else {
                $("#licencearea").show();
            }

            if (data.edition != "Enterprise") {
                if (data.migFail == true) {
                    migFail();
                }
                $(".reg_owner").text(data.owner);
            } else {
                $(".reg_owner").html(Messages.EnterpriseOwner.format(data.provider.Name, data.provider.URL, data.provider.SupportURL));
            }

            if (typeof (UpdateData) !== 'undefined') {
                if (data.backend != UpdateData.LatestMCMA) {
                    if (UpdateShown == false) {
                        createWarning(Messages.Title_UpdateAvailable, Messages.Title_MCMAUpdate.format(UpdateData.LatestMCMA, UpdateData.LatestMCMAChangeSet), showUpdates);
                        UpdateShown = true;
                    }
                }

                if (data.mc != "[Not Running]" && data.mc != latestMC) {
                    if (UpdateShown == false) {
                        createWarning(Messages.Title_UpdateAvailable, Messages.Title_MinecraftUpdate.format(data.mclatest.release), showUpdates);
                        UpdateShown = true;
                    }
                }
            }
        }
    });
}

function addLicence() {
    var key = $("#newKey").val();

    if (key.indexOf("@") > -1)
    {
        showModal("Legacy licence", "The licence key you have entered is a legacy licence, which is no longer valid. You can pick up your new licence by logging into the <a href='http://manage.cubecoders.com'>CubeCoders licence manager</a>.");
        return;
    }

    requestData(APICommands.AddLicence, { NewKey: key }, function (data) {
        if (data.newtype == "Personal") {
            showModal(Messages.Title_InvalidLicence, Messages.Message_InvalidLicence, Icons.Info, hideModal, null);
        } else {
            showModal(Messages.Title_LicenceAdded, Messages.Message_LicenceAdded, Icons.Info, hideModal, null);
            $("#licencearea").hide();
            doLogout();
        }
    });
}

function showUpdates() {
    $("#st_6").mousedown();
    setTimeout(function () { $("#tabhead_about_updates").mousedown(); }, 500);
}

/////////////////////////////////////
//Server Configuration
/////////////////////////////////////

var settingsArray = {
    /*McMyAdmin.conf*/
    "server.name": "setting_servername",
    "notices.announceplayers": "setting_showwelcome",
    "notices.showpermissionserror": "setting_showaccessdenied",
    "notices.savewarning": "setting_warnsave",
    "notices.whitelistmessage": "setting_whitelistmessage",
    "server.statusimage": "setting_statusimage",
    //"mcmyadmin.bannertemplate": "imageTemplate",
    "export.gmtype": "setting_exporting",
    "export.mchatformat": "setting_mchatformat",
    "game.public": "setting_serverpublic",
    "game.motd": "setting_motd",
    "game.whitelist": "setting_whitelistMode",
    "game.whitelistgroup": "setting_whitelistGroup",
    "server.servertype": "setting_servertype",
    "monitoring.severerestart": "setting_severerestart",
    "server.usebukkitbeta": "setting_bukkitbeta",
    "notices.announcegroupchange": "setting_announcechange",
    "server.sleepwhenempty": "setting_sleep",
    "server.serversleepmessage": "setting_sleepmsg",
    "mcmyadmin.backupoverflowmode": "settng_backupoverflow",
    "mcmyadmin.includepermissionsinscheduledbackup": "setting_schedperm",
    "mcmyadmin.includepluginsinscheduledbackup": "setting_schedplugs",
    "mcmyadmin.includepluginconfiginscheduledbackup": "setting_schedconf",

    /*server.properties*/
    "spawn-monsters": "setting_monsters",
    "spawn-animals": "setting_animals",
    "allow-nether": "setting_nether",
    "pvp": "setting_pvp",
    "allow-flight": "setting_flight",
    "max-players": "setting_maxplayers",
    "gamemode": "setting_gamemode",
    "difficulty": "setting_difficulty",
    "view-distance": "setting_distance",
    "generate-structures": "setting_structures",
    "level-seed": "setting_seed",
    "spawn-npcs": "setting_npc",
    "level-type": "setting_worldtype",
    "motd": "setting_mcmotd",
    "snooper-enabled": "setting_snooper",
    "resource-pack": "setting_resourcepack",
    "hardcore": "setting_hardcore",
    "generator-settings": "setting_generatorsettings",
    "enable-command-block": "setting_commandblocks",
    "player-idle-timeout": "setting_timeout",
    "announce-player-achievements": "setting_achivements",
    "eula": "setting_eula"
};

var oldValues = Array();

function setConfig() {
    if (RASclient) { return; }
    var key = $(this).attr('config_key');
    var value = $(this).val();
    setConfigVal(key, value);
    if (RASserver) { requestData(APICommands.SendRASconfigChange, { key: key, value: value }, null); }
}

function setConfigVal(key, value) {
    requestData(APICommands.SetConfig, { Key: key, Value: value }, function () {
        oldValues[key] = value;
        createWarning(Messages.Title_SettingChanged, Messages.Message_SettingChanged.format(key, value), null, 4000);
        updateConfigWarnings();
    });
}

function getConfiguration() {
    requestData(APICommands.GetFullConfig, {}, function (data) {
        if (data == null) { return; }

        var settings = data.settings;

        for (var settingname in settingsArray) {
            var element = "#" + settingsArray[settingname];

            if ($(element) != null) {
                $(element).val(settings[settingname]);
                $(element).attr('config_key', settingname);
                $(element).unbind("change");
                $(element).change(setConfig);
            }

            //oldValues[settingname] = settings[settingname];
        }

        $("#setting_exporting").unbind("change");
        $("#setting_exporting").change(ExportSet);

        if (parseBool(settings['online-mode']) == false) {
            createWarning(Messages.WarningOfflineTitle, Messages.WarningOfflineMessage, null);
        }

        if (parseBool(settings['server.forcesleepmode'])) {
            $("#serversleepsetting").hide();
        }
        else {
            $("#serversleepsetting").show();
        }

        if (parseBool(settings['mcmyadmin.locktovanilla'])) {
            $("#servertypesetting").hide();
            $("#servertypelocked").show();
        }
        else {
            $("#servertypesetting").show();
            $("#servertypelocked").hide();
        }

        MinPassGrade = parseInt(settings['security.minimumpasswordgrade']);

        if (LastPWGrade < MinPassGrade) { weakPassword(); }

        $(".maxplayerslimit").text(settings['limits.maxplayers']);
        oldValues = settings;
        updateConfigWarnings();
    });
}

function updateConfigWarnings() {
    if (oldValues['export.gmtype'] != "None") {
        $("#feature_exporting").hide();
    }
    else { $("#feature_exporting").show(); }
}

function ExportSet() {
    var expSetting = $("#setting_exporting");
    var oldKey = expSetting.attr('config_key');

    if (expSetting.val() == "None") {
        setConfigVal(oldKey, expSetting.val());
        return;
    }

    showModal(Messages.Title_ExportWarning, Messages.Message_ExportWarning, Icons.Warning, function () {
        setConfigVal(oldKey, expSetting.val());
        hideModal();
    }, function () {
        expSetting.val(oldValues[oldKey]);
        hideModal();
    });
}

/////////////////////////////////////
//Users and Groups Management
/////////////////////////////////////

var CurrentGroup = "";
var worldInfo;

function getWorldNameFromID(id) {
    return worldInfo[id].name;
}

function scanWorlds() {
    requestData(APICommands.ScanWorlds, {}, function (data) {
        getWorlds(null);
    });
}

function getWorlds(callback) {
    requestData(APICommands.GetWorlds, {}, function (data) {
        worldInfo = {};

        $("#WorldList").empty();
        $("#selectedAddWorld").empty();

        for (var w in data.worlds) {
            var world = data.worlds[w];
            worldInfo[world.ID] = world;
            var worldEntry = $("<div class='vlistitem'></div>");
            worldEntry.text(world.Name);
            worldEntry.attr("data-world", world.ID);
            $("#WorldList").append(worldEntry);

            var worldOptEntry = $("<option></option>");
            worldOptEntry.text(world.Name);
            worldOptEntry.attr("value", world.ID);
            $("#selectedAddWorld").append(worldOptEntry);
        }

        $("#WorldList .vlistitem").click(worldSelected);

        if (callback != null) { callback(); }
    });
}

function worldSelected() {
    $("#WorldList .vlistitem").removeClass("selected");
    var worldid = $(this).data("world");
    var selectedWorld = worldInfo[worldid];
    $(this).addClass("selected");

    if (selectedWorld.IsTopLevel) {
        $("#nestedWorld").hide();
        $("#backupcb").show();
    }
    else {
        $("#nestedWorld").show();
        $("#nestedWorld").text("'{0}' is a child world of '{1}', and is backed up whenever '{1}' is.".format(selectedWorld.Name, selectedWorld.Parent));
        $("#backupcb").hide();
    }

    $("#worldname").text(selectedWorld.Name);
    $("#worldpath").text(selectedWorld.Path);
    $("#worldbackup").prop('checked', selectedWorld.IncludeInBackups);
    $("#worldbackup").data("world", worldid);
    $("#currentworldholder").show();
}

function toggleWorldBackup() {
    var worldID = $(this).data("world");
    var enabled = $("#worldbackup").is(":checked");
    worldInfo[worldID].IncludeInBackups = enabled;
    requestData(APICommands.SetWorldBackup, { WorldID: worldID, Included: enabled }, function () { });
}

function addGroupMemeber() {
    var newMember = $("#newGroupUser").val();
    $("#newGroupUser").val("");
    requestData(APICommands.AddGroupValue, { Group: CurrentGroup, Type: GroupArgs.GroupMembers, Value: newMember }, function () {
        getGroup(CurrentGroup);
    });
}

function addGroupCommand() {
    var newCommand = $("#newGroupCommand").val();
    $("#newGroupCommand").val("");
    requestData(APICommands.AddGroupValue, { Group: CurrentGroup, Type: GroupArgs.GroupCommands, Value: newCommand }, function () {
        getGroup(CurrentGroup);
    });
}

function addGroupWorld() {
    var newWorld = $("#selectedAddWorld").val();
    requestData(APICommands.AddGroupValue, { Group: CurrentGroup, Type: GroupArgs.GroupWorlds, Value: newWorld }, function () {
        getGroup(CurrentGroup);
    });
}

function addGroup() {
    var newGroupName = $("#newGroupName").val();
    $("#newGroupName").val("");
    requestData(APICommands.CreateGroup, { Name: newGroupName }, function () {
        getGroups();
    });
}

function delGroupWorld() {
    var worldID = $(this).data("world");
    requestData(APICommands.RemoveGroupValue, { Group: CurrentGroup, Type: GroupArgs.GroupWorlds, Value: worldID }, function () {
        getGroup(CurrentGroup);
    });
}

function delGroupMember() {
    var member = $(this).data("member");
    requestData(APICommands.RemoveGroupValue, { Group: CurrentGroup, Type: GroupArgs.GroupMembers, Value: member }, function () {
        getGroup(CurrentGroup);
    });
}

function delGroupCommand() {
    var command = $(this).data("command");
    requestData(APICommands.RemoveGroupValue, { Group: CurrentGroup, Type: GroupArgs.GroupCommands, Value: command }, function () {
        getGroup(CurrentGroup);
    });
}

function renameGroup() {
    var newName = $("#groupRenameValue").val();
    $("#groupRenameValue").val("");
    requestData(APICommands.RenameGroup, { Group: CurrentGroup, NewName: newName }, function () {
        getGroup(newName);
        showModal(Messages.GroupRenameTitle, Messages.GroupRenameMessage, Icons.Info, hideModal, null);
    });
}

function delGroup() {
    showModal(Messages.GroupDeleteTitle, Messages.GroupDeleteMessage.format(CurrentGroup), Icons.Warning, function () {
        requestData(APICommands.DeleteGroup, { Name: CurrentGroup }, function () {
            getGroups();
            hideModal();
        });
    }, hideModal);
}

var lastWarnings = [];

function getGroupWarnings() {
    requestData(APICommands.GetGroupWarnings, {}, function (data) {
        lastWarnings = data.data;

        if (parseInt(data.count) > 0) {
            $("#groupwarncount").text(data.count);
            $("#feature_groups").show();
        }
        else {
            $("#feature_groups").hide();
        }
    });
}

function showGroupWarnings() {
    var data = "<ul>";

    for (var i in lastWarnings) {
        var warn = lastWarnings[i];
        data += "<li>{0}</li>".format(warn);
    }

    data += "</ul>";

    showModal("Group Configuration Issues", data, Icons.Info, hideModal, null, null);
}

function getGroups(callback) {
    requestData(APICommands.GetGroups, {}, function (data) {
        $("#worldgrouplist").empty();
        $("#inheritlist").empty();
        $("#setting_whitelistGroup").empty();
        $("#groupworlds").empty();

        data.groups.sort();

        $("#inheritlist").append("<option value=\"\">None</option>");
        $("#setting_whitelistGroups").append("<option value=\"\">None</option>");

        for (var i in data.groups) {
            var group = data.groups[i];

            var groupEntry = $("<div class=\"vlistitem\"></div>");
            groupEntry.text(group);
            $("#worldgrouplist").append(groupEntry);

            var newOption = $("<option></option>");
            newOption.text(group);
            newOption.attr("value", group);

            $("#inheritlist").append(newOption);
            $("#setting_whitelistGroup").append(newOption.clone());
        }

        $("#worldgrouplist .vlistitem").click(function () {
            $("#worldgrouplist .selected:first").removeClass("selected");
            $(this).addClass("selected");
            CurrentGroup = $(this).text();
            $("#groupInfoArea").fadeOut(function () {
                getGroup(CurrentGroup);
            });
        });

        /*var settingsEntry = $("<div class=\"vlistitem\">{0}</div>".format(Messages.GroupSettings));
        $("#worldgrouplist").prepend(settingsEntry);*/

        $("#worldgrouplist .vlistitem:first").click();

        getGroupWarnings();

        if (callback != null) {
            callback();
        }
    });
}

var GroupAttribsArray = {
    "inheritlist": "Inherits",
    "colorlist": "Color",
    "groupbuild": "CanBuild",
    "groupinteract": "CanInteract",
    "groupprefix": "Prefix",
    "groupsuffix": "Suffix",
    "groupdefault": "IsDefault",
};

function updateGroupSetting() {
    var updateType = GroupAttribsArray[$(this).attr('id')];
    var newValue = $(this).val();
    requestData(APICommands.AddGroupValue, { Group: CurrentGroup, Type: updateType, Value: newValue }, function () {
        getGroup(CurrentGroup);
    });
    return true;
}

function getGroup(groupName) {
    requestData(APICommands.GetGroupInfo, { Group: groupName }, function (data) {
        $("#groupusers").empty();
        $("#groupcommands").empty();
        $("#groupworlds").empty();

        data.info.Members.sort();
        data.info.CommandList.sort();

        var i, newEntry;

        for (i in data.info.Members) {
            var member = data.info.Members[i];
            var newEntry = $("<div class=\"vlistitem shortitem\"><div class=\"vlisttext\"></div><div class=\"tinyButton\"></div></div>");
            newEntry.find(".vlisttext").text(member);
            newEntry.find(".tinyButton").attr("data-member", member);
            $("#groupusers").append(newEntry);
        }

        $("#groupusers .tinyButton").click(delGroupMember);

        for (i in data.info.CommandList) {
            var command = data.info.CommandList[i];
            var newEntry = $("<div class=\"vlistitem shortitem\"><div class=\"vlisttext\"></div><div class=\"tinyButton\"></div></div>");
            newEntry.find(".vlisttext").text(command);
            newEntry.find(".tinyButton").attr("data-command", command);
            $("#groupcommands").append(newEntry);
        }

        $("#groupcommands .tinyButton").click(delGroupCommand);

        for (i in GroupAttribsArray) {
            var e = $("#" + i);
            e.val(data.info[GroupAttribsArray[i]]);
            e.unbind("change").change(updateGroupSetting);
        }

        for (i in data.info.Worlds) {
            var world = worldInfo[data.info.Worlds[i]];

            if (world == undefined) { continue; }
            var newEntry = $("<div class=\"vlistitem shortitem\"><div class=\"vlisttext\"></div><div class=\"tinyButton\"></div></div>");
            newEntry.find(".vlisttext").text(world.Name);
            newEntry.find(".tinyButton").attr("data-world", world.ID);
            $("#groupworlds").append(newEntry);
        }

        $("#groupworlds .tinyButton").click(delGroupWorld);

        $("#inheritlist").val(data.info.Inherits);
        $("#colorlist").val(data.info.Color);
        $("#groupbuild").val(data.info.CanBuild.toString());
        $("#groupinteract").val(data.info.CanInteract.toString());
        $("#groupprefix").val(data.info.Prefix);
        $("#groupsuffix").val(data.info.Suffix);
        $("#groupdefault").val(data.info.IsDefault.toString());

        updateColor();

        $("#groupSettingsHeader").text(Messages.GroupSettings.format("Default", groupName));

        $("#groupInfoArea").fadeIn();
    });
}

function updateColor() {
    var opt = $("#colorlist").get(0);
    var selected = opt.options[opt.selectedIndex];
    $("#colorpreview").css("background-color", selected.style.backgroundColor);
}

/////////////////////////////////////
//User Handling
/////////////////////////////////////

var UserData = Array();

function showChangePassword(noCancel) {

    if (noCancel == true) {
        $("#changePasswordCancelButton").hide();
    }
    else {
        $("#changePasswordCancelButton").show();
    }

    $("#passwdchange").fadeIn();
}

function hidePwChange() {
    $("#passwdchange").fadeOut(function () {
        $("#oldpwd").val("");
        $("#newpwd").val("");
        $("#newpwd2").val("");
    });
}

function pwChangeOk() {
    var pw1 = $("#newpwd").val();
    var pw2 = $("#newpwd2").val();
    var oldpwd = $("#oldpwd").val();

    if (pw1 != pw2) {
        showModal(Messages.Title_NoPassMatch, Messages.Message_NoPassMatch, Icons.Warning, hideModal, null);
    }
    else if (pw1 == "") {
        showModal(Messages.Title_NoPass, Messages.Message_NoPass, Icons.Warning, hideModal, null);
    }
    else if (getPasswordStrength(pw1) < MinPassGrade) {
        showModal(Messages.Title_WeakPassword, Messages.Message_WeakPassword, Icons.Warning, hideModal, null);
    }
    else {
        requestData(APICommands.ChangePassword, { OldPassword: oldpwd, NewPassword: pw1 }, function (data) {
            if (data.status == 200) {
                hidePwChange();
                showModal(Messages.Title_PassChanged, Messages.Message_PassChanged, Icons.Info, hideModal, null);
            } else {
                showModal(Messages.Title_IncorrectPassword, Messages.Message_IncorrectPassword, Icons.Info, hideModal, null);
            }
        });
    }
}

function getUsers() {
    requestData(APICommands.GetUsers, {}, function (data) {
        if (data) {
            $("#MCMAUserList").empty();

            UserData = data.data;

            for (var i in UserData) {
                var user = UserData[i];

                var newEntry = $("<div class='vlistitem'></div>");
                newEntry.text(user.Username);
                newEntry.click(displayUser);
                $("#MCMAUserList").append(newEntry);
            }

            $("#MCMAUserList .vlistitem:first").click();
        }
    });
}

var CurrentUser = "";

function displayUser() {
    $("#MCMAUserList .selected:first").removeClass("selected");
    $(this).addClass("selected");
    CurrentUser = $(this).text();

    var thisUser = UserData[CurrentUser];

    for (var i = 1; i < 2097152; i *= 2) {
        var flag = (thisUser.AuthMask & i);
        var fid = "#up_{0}".format(i);
        var flagEl = $(fid);
        flagEl.prop("checked", parseBool(flag));

        var perm = (thisUser.UserMask & i);
        var pid = "#uf_{0}".format(i);
        var pidEl = $(pid);
        pidEl.prop("checked", parseBool(perm));
    }
}

function toggleUserFlag() {
    var newValue = true;
    var flagEl = $(this);
    var flag = parseInt(flagEl.val());
    var requestType = APICommands.UnsetUserMask;

    if (flagEl.is(":checked")) {
        requestType = APICommands.SetUserMask;
        newValue = false;
    }

    requestData(requestType, { User: CurrentUser, Mask: flag }, function (data) {
        if (data.status != 200) {
            flagEl.prop("checked", parseBool(newValue));

            if (data.status == 403) {
                showModal(Messages.Title_UserNoModify, Messages.Message_UserNoModify, Icons.Info, hideModal, null);
            }
        } else {
            UserData[CurrentUser].AuthMask ^= flag;
        }
    });
}

function toggleSettingFlag() {
    var newValue = true;
    var flagEl = $(this);
    var flag = parseInt(flagEl.val());
    var op = APICommands.UnsetUserSetting;

    if (flagEl.is(":checked")) {
        op = APICommands.SetUserSetting;
        newValue = false;
    }

    requestData(op, { User: CurrentUser, Mask: flag }, function (data) {
        if (data.status != 200) {
            flagEl.prop("checked", parseBool(newValue));

            if (data.status == 403) {
                showModal(Messages.Title_UserNoModify, Messages.Message_UserNoModify, Icons.Info, hideModal, null);
            }
        } else {
            UserData[CurrentUser].UserMask ^= flag;
        }
    });
}

function changeUserPassword() {
    var pw1 = $("#newuserpass").val();
    var pw2 = $("#newuserpass_confirm").val();

    if (pw1 != pw2) {
        showModal(Messages.Title_NoPassMatch, Messages.Message_NoPassMatch, Icons.Info, hideModal, null);
    }
    else if (pw1 == "") {
        showModal(Messages.Title_NoPass, Messages.Message_NoPass, Icons.Info, hideModal, null);
    }
    else {
        requestData(APICommands.ChangeUserPassword, { Username: CurrentUser, NewPassword: pw1 }, function (data) {
            if (data == null) { return; }

            if (data.status == 403) {
                showModal(Messages.Title_UserNoModify, Messages.Message_UserNoModify, Icons.Info, hideModal, null);
            }
            else if (data.status == 401) {
                showModal(Messages.Title_NoCurrentUser, Messages.Message_NoPassMatch, Icons.Info, hideModal, null);
            }
            else if (data.status == 200) {
                showModal(Messages.Title_PassChanged, Messages.Message_PassChanged, Icons.Info, hideModal, null);
            }

            $("#newuserpass").val("");
            $("#newuserpass_confirm").val("");
        });
    }
}

function deleteUser() {
    showModal(Messages.Title_DeleteUser, Messages.Message_DeleteUser.format(CurrentUser), Icons.Warning, function () {
        requestData(APICommands.DeleteUser, { Username: CurrentUser }, function (data) {
            if (data.status == 403) {
                showModal(Messages.Title_UserNoModify, Messages.Message_UserNoModify, Icons.Info, hideModal, null);
            } else {
                hideModal();
                getUsers();
            }
        });
    }, hideModal);
}

function addUser() {
    var newUsername = $("#newUserName").val();

    if (newUsername == "") {
        showModal(Messages.Title_InvalidUser, Messages.Message_InvalidUser, Icons.Warning, hideModal, null);
    } else {
        $("#newUserName").val("");
        requestData(APICommands.CreateUser, { NewUsername: newUsername }, function (data) {
            if (data.status == 503) {
                showModal(Messages.Title_NotSupportedInVersion, Messages.Message_MultiUserPersonal, Icons.Info, hideModal, null);
            } else {
                getUsers();
            }
        });
    }
}

/////////////////////////////////////
//Schedule Handling
/////////////////////////////////////

function fillTimeSelects() {
    var i;

    for (i = 0; i < 60; i++) {
        $("#selMinPast").append("<option>" + padNumber(i) + "</option>");
    }

    for (i = 0; i < 24; i++) {
        for (var j = 0; j < 60; j++) {
            $("#selAtTime").append("<option>" + padNumber(i) + ":" + padNumber(j) + "</option>");
        }
    }
}

function selectTimeType(type) {
    $("#selEvery").hide();
    $("#selEveryHour").hide();
    $("#selEventTrigger").hide();
    $("#selPast").hide();
    $("#selTime").hide();

    switch (parseInt(type)) {
        case 0: $("#selEvery").show(); break;
        case 1: $("#selEveryHour").show(); break;
        case 2: $("#selPast").show(); break;
        case 3: $("#selTime").show(); break;
        case 4: $("#selEventTrigger").show(); break;
    }
}

function getEventName(eventId, data) {
    switch (parseInt(eventId)) {
        case 100: return (Messages.EventSaveWorldState);
        case 200: return (Messages.EventRestartServer);
        case 250: return (Messages.EventRestartEmptyServer);
        case 260: return (Messages.EventRestartRAM.format(data));
        case 270: return (Messages.EventStopServer);
        case 280: return (Messages.EventStartServer);
        case 400: return ("Say a message: " + data);
        case 300: return ("Send a server notice: " + data);
        case 700: return ("Send a console command: " + data);
        case 900: return ("Run executable: " + data);
        case 910: return ("Redirect executable: " + data);
        case 1000: return ("Take a backup of the world");
        case 1500: return ("Disable whitelisting");
        case 1600: return ("Enable groups based whitelisting");
        case 1700: return ("Restart server and rotate log file");
        case 1800: return ("Check for optional McMyAdmin updates and install if available");
    }
    return ("");
}

function getEventParamDesc(eventId) {
    switch (parseInt(eventId)) {
        case 260: return (Messages.ParamRAM);
        case 400: return (Messages.ParamMessage);
        case 300: return (Messages.ParamMessage);
        case 700: return (Messages.ParamCommand);
        case 900: return (Messages.ParamExec);
        case 910: return (Messages.ParamExec);
    }

    return ("");
}

function selectEventType(type) {
    var desc = getEventParamDesc(type);
    if (desc == "") {
        $("#eventparam").hide();
        $("#ParamDescription").text("");
    }
    else {
        $("#eventparam").show();
        $("#ParamDescription").text(desc);
    }
}

function padNumber(num) {
    if (num < 10) {
        num = "0" + num;
    }
    return (num);
}

function getScheduleTimeString(hours, minutes, trigger) {
    if (trigger != 0) {
        return ("When " + EventTriggerNames[trigger]);
    }

    if (minutes == 0 && hours < 0) {
        return ("Every " + Math.abs(hours) + " hours");
    }

    if (hours == -1 && minutes < 0) {
        return ("Every " + Math.abs(minutes) + " minutes");
    }

    if (hours == -1 && minutes > 0) {
        return (padNumber(minutes) + " minutes past every hour");
    }

    return ("Once per day at " + padNumber(hours) + ":" + padNumber(minutes));
}

function addNewEvent() {
    var hours = 0;
    var mins = 0;
    var trigger = 0;

    var selTimeType = $("#timeType").val();

    switch (selTimeType) {
        case "0":
            {
                hours = -1;
                mins = $("#selMinute").val();
                break;
            }
        case "1":
            {
                hours = $("#selHour").val();
                break;
            }
        case "2":
            {
                hours = -1;
                mins = $("#selMinPast").val();
                break;
            }
        case "3":
            {
                var time = $("#selAtTime").val();
                var timeParts = time.split(":", 2);
                hours = timeParts[0];
                mins = timeParts[1];
                break;
            }
        case "4":
            {
                trigger = $("#selTrigger").val();
                break;
            }
    }

    var eventType = $("#selEvent").val();
    var eventData = $("#eventparam").val();

    requestData(APICommands.AddScheduleItem, { Hours: hours, Mins: mins, Type: eventType, TriggerEvent: trigger, Param: eventData }, getSchedule);

    $("#eventparam").val("");
}

function deleteEvent(eventIndex) {
    requestData(APICommands.DeleteScheduleItem, { Index: eventIndex }, getSchedule);
}

function runEvent(eventIndex) {
    requestData(APICommands.RunScheduleItem, { Index: eventIndex }, $.noop);
}

function parseDate(data) {
    var milliseconds = data.substring(6, data.length - 2);
    var d = new Date(parseInt(milliseconds));
    return (d);
}

function getSchedule() {
    requestData(APICommands.GetSchedule, {}, function (data) {
        if (data == null) { return; }

        $("#offsetmins").text(Messages.Text_OffsetMins.format(data.offset));

        var schedule = data.schedule;
        $("#scheduleItems").empty();
        for (var i in schedule) {
            var scheduleItem = schedule[i];

            var newItem = $("<tr><td class=\"firstCol\">" + getScheduleTimeString(scheduleItem.AtTime.OnHour, scheduleItem.AtTime.OnMinute, scheduleItem.TriggerEvent) + "</td>" +
                                           "<td class=\"eventName\"></td>" +
                                           "<td><input class=\"auth_4096\" onclick=\"runEvent(" + i + ");\" type=\"button\" value=\"" + Messages.ScheduleRunNow + "\"/></td>" +
                                           "<td><input class=\"auth_4096\" onclick=\"deleteEvent(" + i + ");\" type=\"button\" value=\"" + Messages.ScheduleDelete + "\"/></td></tr>");
            newItem.children(".eventName").text(getEventName(scheduleItem.EventType, scheduleItem.EventData));
            $("#scheduleItems").append(newItem);
        }
    });
}

function resetSchedule() {
    showModal(Messages.WarningResetSchedule, Messages.WarningResetScheduleText, Icons.Warning, function () {
        requestData(APICommands.ResetSchedule, {}, getSchedule);
        hideModal();
    }, hideModal);
}

/////////////////////////////////////
//Updates
/////////////////////////////////////

function UpdateMCMA() {
    stopUpdates();
    performAction(APICommands.UpdateMCMA);
    showModal(Messages.Title_UpdatingMCMA, Messages.Message_UpdatingMCMA, Icons.Info, null, null);
    setTimeout(function () {
        window.location.reload();
    }, 60000);
}

function UpdateMC() {
    if ($("#setting_servertype").val() == "CraftBukkit" && parseBool($("#setting_bukkitbeta").val()) == false) {
        if (latestMC != UpdateData.LatestMinecraftBukkitCompat) {
            showModal(Messages.Title_BukkitVersionWarn, Messages.Message_BukkitVersionWarn.format(latestMC, UpdateData.LatestMinecraftBukkitCompat), Icons.Warning, function () { hideModal(); DoUpdateMC(true); }, hideModal);
        }
        else {
            DoUpdateMC(true);
        }
    }
    else {
        DoUpdateMC();
    }
}

function DoUpdateMC(isCB) {
    var useText = (isCB) ? Messages.Title_UpdatingCB : Messages.Title_UpdatingMC;

    requestData(APICommands.UpdateMC, {}, function (data) {
        if (data.status == 200) {
            RunningTasks[Tasks.Update] = createTask(useText);
            UpdateIntervals[UpdateEvents.GetBackupStatus] = setInterval(getUpdateStatus, 500);
        }
    });
}

function getUpdateStatus() {
    requestData(APICommands.GetUpdateStatus, {}, function (data) {
        if (data.updaterunning == false) {
            setTaskStatus(RunningTasks[Tasks.Update], 100);
            clearInterval(UpdateIntervals[UpdateEvents.GetBackupStatus]);
            endTask(RunningTasks[Tasks.Update]);
            getVersions();

            if (data.percent == -1) {
                showModal(Messages.Title_ErrorUpdate, Messages.Message_ErrorUpdate, Icons.Warning, hideModal, null, 10000);
            } else {
                createWarning(Messages.Title_UpdateComplete, Messages.Message_UpdateComplete, null, 10000);
            }
        } else {
            setTaskStatus(RunningTasks[Tasks.Update], data.percent);
        }
    });
}

/////////////////////////////////////
//Backups
/////////////////////////////////////

var LastBackupList;

function getSaneTimestamp(fromDate) {
    return (fromDate.toDateString() + " " + fromDate.toLocaleTimeString());
}

function getBackupList() {
    requestData(APICommands.GetBackups, {}, function (data) {
        if (data == null) { return; }

        var backupData = data["data"];
        LastBackupList = {};

        $("#backupInfo").text("Backups stored: {0} of {1} ({2}/{3} MB used)".format(data.backupcount, data.backupmax, data.backuptotalsize, data.backuptotalsizemax));
        $("#backuplistbody").empty();

        for (var i in backupData) {
            var backupItem = backupData[i];

            if (backupItem == undefined) { continue; }

            LastBackupList[backupItem.BackupID] = backupItem;

            var theDate = parseDate(backupItem.DateTaken);
            var SizeMB = Math.round(backupItem.TotalExtractedSize / 1024 / 1024);

            var newItem = $("<tr><td><input type=\"radio\" name=\"selectedBackup\" class=\"selectedBackupRadio\" value=\"{0}\"/></td><td>{1}</td><td class=\"backupName\"></td><td>{3} MB</td></tr>".format(backupItem.BackupID, getSaneTimestamp(theDate), backupItem.Name, SizeMB));
            newItem.children(".backupName").text(backupItem.Name);

            //newItem = newItem.format(getSaneTimestamp(theDate), backupItem.SizeMB, backupItem.Name, backupItem.Filename, backupItem.Created, i);

            $("#backuplistbody").append(newItem);
        }

        $(".selectedBackupRadio").click(selectedBackupChanged);
        $(".selectedBackupRadio:first").attr("selected", "selected");
    });
}

var selectedBackup;

function selectedBackupChanged() {
    var value = $(this).val();
    selectedBackup = LastBackupList[value];
    $("#restoreServer").prop("checked", false);
    $("#restorePlugins").prop("checked", false);
    $("#restoreConfig").prop("checked", false);
    $("#restorePermissions").prop("checked", false);
    $("#restoreWorlds").prop("checked", false);

    $("#restoreServer, label[for=restoreServer]").css("display", (selectedBackup.ContainsServer ? "inline" : "none"));
    $("#restorePlugins, label[for=restorePlugins]").css("display", (selectedBackup.ContainsPlugins ? "inline" : "none"));
    $("#restoreConfig, label[for=restoreConfig]").css("display", (selectedBackup.ContainsPluginConfigs ? "inline" : "none"));
    $("#restorePermissions, label[for=restorePermissions]").css("display", (selectedBackup.ContainsPermissions ? "inline" : "none"));
}

function downloadBackup(file) {
    window.open(location.href + "Backups/" + file);
}

function restoreBackup() {
    var restoreWorlds = $("#restoreWorlds").is(":checked");
    var restoreServer = $("#restoreServer").is(":checked");
    var restorePlugins = $("#restorePlugins").is(":checked");
    var restoreConfig = $("#restoreConfig").is(":checked");
    var restorePermissions = $("#restorePermissions").is(":checked");

    showModal(Messages.BackupRestoreTitle, Messages.BackupRestoreText, Icons.Question, function () {
        requestData(APICommands.RestoreBackup, { BackupID: selectedBackup.BackupID, RestoreWorlds: restoreWorlds, RestorePluginConfig: restoreConfig, RestorePlugins: restorePlugins, RestoreServer: restoreServer, RestorePermissions: restorePermissions }, function (data) {
            if (data.status == 200) {
                UpdateIntervals[UpdateEvents.GetRestoreStatus] = setInterval(getRestoreStatus, 2000);

                RunningTasks[Tasks.Restore] = createTask(Messages.BackupRestoreRunning);
            }
        });

        hideModal();

    }, hideModal);
}

function getRestoreStatus() {
    requestData(APICommands.GetBackupStatus, {}, function (result) {
        var data = result.data;

        var percent = Math.round((data.DoneFiles / data.TotalFiles) * 100);
        var finished = (data.IsRunning == false);

        if (finished == true) {
            setTaskStatus(RunningTasks[Tasks.Restore], 100);
            endTask(RunningTasks[Tasks.Restore]);
            clearInterval(UpdateIntervals[UpdateEvents.GetRestoreStatus]);

            getBackupList();
        }
        else {
            setTaskStatus(RunningTasks[Tasks.Restore], percent);
        }
    });
}

function deleteBackup(index) {
    var theDate = parseDate(selectedBackup.DateTaken);

    showModal(Messages.BackupDeleteTitle, Messages.BackupDeleteWarning + "<br/><br/>" + escape(selectedBackup.Name) + " - " + getSaneTimestamp(theDate), Icons.Warning, function () {

        requestData(APICommands.DeleteBackup, { BackupID: selectedBackup.BackupID }, getBackupList);
        hideModal();

    }, hideModal);
}

function TakeBackup() {
    var label = $("#backuplabel").val();
    var backupserver = $("#backupserver").is(":checked");
    var backupplugins = $("#backupplugins").is(":checked");
    var backupconfig = $("#backupconfig").is(":checked");
    var backuppermissions = $("#backuppermissions").is(":checked");
    $("#backuplabel").val("");

    var match = new RegExp("[A-Za-z0-9_]+");

    if (match.test(label) == false) {
        showModal(Messages.BackupNameTitle, Messages.BackupNameMessage, Icons.Warning, hideModal, null);
        return;
    }

    requestData(APICommands.TakeBackup, { Label: label, IncludePermissions: backuppermissions, IncludePlugins: backupplugins, IncludeConfig: backupconfig, IncludeServer: backupserver, IncludeWorlds: true }, function (data) {
        if (data.status == 200) {
            UpdateIntervals[UpdateEvents.GetBackupStatus] = setInterval(getBackupStatus, 2000);

            RunningTasks[Tasks.Backup] = createTask(Messages.BackupRunning);
        }
    });
}

function getBackupStatus() {
    requestData(APICommands.GetBackupStatus, {}, function (result) {
        var data = result.data;
        var percent = Math.round((data.DoneFiles / data.TotalFiles) * 100);
        var finished = (data.IsRunning == false);

        if (finished == true) {
            setTaskStatus(RunningTasks[Tasks.Backup], 100);
            endTask(RunningTasks[Tasks.Backup]);
            clearInterval(UpdateIntervals[UpdateEvents.GetBackupStatus]);

            getBackupList();
        }
        else {
            setTaskStatus(RunningTasks[Tasks.Backup], percent);
        }
    });
}

function deleteWorld() {
    showModal(Messages.Title_DeleteWorld, Messages.Message_DeleteWorld, Icons.Warning, function () {
        performAction(APICommands.DeleteWorld);
        hideModal();
    }, hideModal);
}

/////////////////////////////////////
//Plugins
/////////////////////////////////////

function refreshPlugins() {
    requestData(APICommands.RefreshPlugins, {}, getPluginList);
}

function getPluginList() {
    requestData(APICommands.GetPlugins, {}, function (data) {
        if (data) {
            var plugins = data.plugins;

            $("#PluginList").empty();

            for (var i in plugins) {
                var plugin = plugins[i];

                var enabledStr = (plugin.Enabled) ? Messages.Enabled : Messages.Disabled;
                var checkedStr = (plugin.Enabled) ? " checked=\"checked\" " : "";

                var newEntry = "<div class=\"PluginEntry\">" +
                                "<span class=\"PluginStatus\"><label for=\"FF" + i + "\">" + enabledStr + "</label><input onclick=\"setPluginState('" + plugin.Name + "',this);\" type=\"checkbox\"" + checkedStr + "id=\"FF" + i + "\"/></span>" +
                                            "<h4>" + $.trim(plugin.Name) + " " + $.trim(plugin.Version) + " <span class=\"PluginAuthor\"> - " + plugin.Authors + "</span></h4>" +
                                            "<p>Description:<br />" + plugin.Description + "</p></div>";

                $("#PluginList").append(newEntry);
            }
        }
    });
}

function setPluginState(name, source) {
    var checked = $(source).is(':checked');

    requestData(APICommands.SetPluginState, { Plugin: name, State: checked }, function (data) {
        if (data.status == 200) {
            if (data.newstate != checked) {
                showModal(Messages.PluginChangeStateTitle, Messages.PluginChangeStateMessage, Icons.Warning, hideModal, null);
            }

            $(source).prop('checked', data.newstate);

            var enabledStr = data.newstate ? Messages.Enabled : Messages.Disabled;

            $(source).prev().text(enabledStr);
        }
        else {
            $(source).prop('checked', !checked);
        }
    });
}

function BukgetUnavail() {
    showModal("Bukget query failed.", "The Bukget query failed. The bukget service may be unavailable, or you may have connectivity issues. Please try again later.", Icons.Info, hideModal, null);
}

var CategoriesFetched = false;
function getBukgetCategories() {
    if (CategoriesFetched == true) { return; }

    requestData(APICommands.GetBukgetCategories, {}, function (data) {
        if (data.status == 503) {
            BukgetUnavail(); return;
        }

        $("#BukgetCategories").empty();

        $("#BukgetCategories").append("<div class='vlistitem' data-special='SR' id='bukgetsearchheader'>Search Results</div>");

        $("#bukgetsearchheader").hide();

        for (var i in data) {
            var entry = data[i];

            $("#BukgetCategories").append("<div class='vlistitem' data-category='{0}'>{0}</div>".format(entry.name));
        }

        $("#BukgetCategories .vlistitem").click(getBukgetPluginsForCategory);

        CategoriesFetched = true;
    });
}

var searchResults = {};

function searchBukgetPlugins() {
    var query = $("#BukgetSearchQuery").val();

    $("#BukgetPlugins").scrollTop(0);
    $("#BukgetPlugins").empty();
    $("#BukgetPlugins").append("<div class='vlistitem'>Searching Plugins...</div>");
    $("#bukgetsearchheader").text("Search Results for '{0}'".format(query));

    requestData(APICommands.SearchBukget, { query: query }, function (data) {
        if (data.status == 503) {
            BukgetUnavail(); return;
        }

        $("#bukgetsearchheader").show();
        searchResults = data;
        showSearchResults();
    });
}

function showSearchResults() {
    $("#BukgetCategories .selected").removeClass("selected");
    $("#bukgetsearchheader").addClass("selected");
    $("#BukgetPlugins").empty();
    populatePluginList(searchResults, 0, "");
}

function moreByAuthor() {
    $("#BukgetSearchQuery").val("author:" + selectedPlugin.authors[0]);
    searchBukgetPlugins();
}

function populatePluginList(data, start, category) {
    if (data.length == 0) {
        $("#BukgetPlugins").append("<div class='vlistitem'>No Results</div>");
    }

    if (data.status == 503) {
        BukgetUnavail(); return;
    }

    for (var i in data) {
        var entry = data[i];
        var num = i + start;
        var displayName = entry.plugin_name ? entry.plugin_name : entry.slug;
        var descTag = entry.description ? "<br/><span class='verytiny'>{0}</span>".format(entry.description) : "";

        $("#BukgetPlugins").append("<div class='vlistitem' data-category='{0}' data-name='{1}' data-number='{2}'>{3}{4}</div>".format(category, entry.slug, num, displayName, descTag));
    }

    $("#BukgetPlugins .vlistitem").click(getBukgetPluginInfo);
}

var selectedPlugin;

function downloadPlugin() {
    requestData(APICommands.DownloadBukgetPlugin, { PluginName: selectedPlugin.slug }, function (data) {
        createWarning("Plugin Downloading...", "'{0}' is now downloading and will be ready for use shortly.".format(selectedPlugin.plugin_name), null, 5000);
    });
}

function getBukgetPluginInfo() {
    var plugin = $(this).data("name");

    $("#BukgetPlugins .selected").removeClass("selected");
    $(this).addClass("selected");

    requestData(APICommands.GetBukgetPluginInfo, { PluginName: plugin }, function (data) {
        selectedPlugin = data;
        var displayName = data.plugin_name ? data.plugin_name : data.slug;
        var latestVersion = data.versions[0];
        var displayDesc = data.description ? data.description : "No Description";

        $("#bukgetplugin_name").text(displayName);
        $("#bukgetplugin_desc").text(displayDesc);
        $("#bukgetplugin_link").attr("href", data.dbo_page);
        $("#bukgetplugin_auth").text(data.authors[0]);
        $("#bukkitplugin_ver").text(latestVersion.version);
        $("#bukkitplugin_bukver").text(latestVersion.game_versions[0]);
        $("#bukkitplugin_date").text(new Date(parseInt(latestVersion.date) * 1000).toDateString());
        $("#currentpluginholder").show();
    });
}

function getBukgetPluginsForCategory() {
    var special = $(this).data("special");

    if (typeof special !== 'undefined') {
        showSearchResults();
        return;
    }

    var category = $(this).data("category");
    var start = $(this).data("number");

    if (typeof start === 'undefined') {
        start = 0;
        $("#BukgetPlugins").append("<div class='vlistitem'>Loading Plugins...</div>");
        $("#BukgetCategories .selected").removeClass("selected");
        $(this).addClass("selected");
    }
    else {
        $("#morePlugins").text("Loading...");
    }

    requestData(APICommands.GetBukgetPluginsInCategory, { CategoryName: category, Start: start }, function (data) {
        if (start == 0) {
            $("#BukgetPlugins").scrollTop(0);
            $("#BukgetPlugins").empty();
        }
        else {
            $("#morePlugins").remove();
        }

        populatePluginList(data, start, category);

        if (data.length == 40) {
            $("#BukgetPlugins").append("<div class='vlistitem' id='morePlugins' data-category='{0}' data-name='{1}' data-number='{2}'>{1}</div>".format(category, "More Results...", start + data.length));
        }

        $("#morePlugins").click(getBukgetPluginsForCategory);
    });
}

/////////////////////////////////////
//File Manager
/////////////////////////////////////

var fileManagerPath = "";

function getFriendlySize(input) {
    var suffixes = ["B", "KB", "MB", "GB", "TB", "PB"];
    var index = 0;

    while (input > 1024 && index < 5) {
        input /= 1024;
        index++;
    }

    return input.toFixed(2) + " " + suffixes[index];
}

function getListing() {
    requestData(APICommands.GetDirListing, { path: fileManagerPath }, function (data) {
        var listing = data.data;
        $("#fmContents").empty();
        $("#currentDir").text(fileManagerPath);

        if (fileManagerPath != "") {
            listing.splice(0, 0, { Filename: "..", IsDirectory: true, SizeBytes: 0, IsDownloadable: false, Modified: "" });
        }

        for (var l in listing) {
            var entry = listing[l];
            var type = entry.IsDirectory ? "Folder" : "File";
            var name = $("<td>").text(entry.Filename);
            var size = $("<td>").text(entry.IsDirectory ? "" : getFriendlySize(entry.SizeBytes));
            var mod = $("<td>").text(parseDate(entry.Modified).toLocaleString());
            var row = $("<tr>");
            var itemclass = entry.IsDirectory || entry.IsDownloadable ? "downloadable" : "";
            row.addClass(itemclass);
            row.append("<td><img src='Images/{0}.png' alt='{0}'/></td>".format(type));
            row.append(name);
            row.append(size);
            row.append(mod);
            row.data("type", type);
            row.data("path", fileManagerPath + entry.Filename);
            row.data("name", entry.Filename);
            row.data("size", entry.SizeBytes);
            row.click(listingClicked);
            $("#fmContents").append(row);

            if (!entry.IsDirectory && entry.IsDownloadable) {
                row.click(fileDownload);
            }
        }
    });
}

function setupFileDnD() {
    $("html").on("dragover", NullDNDDrag);
    $("html").on("drop", NullDNDDrop);
    $("#fmContents").on("dragover", DnDDragOver);
    $("#fmContents").on("drop", DnDDragDrop);
}

function NullDNDDrag(event) {
    event.stopPropagation();
    event.preventDefault();
    event.originalEvent.dataTransfer.dropEffect = 'none';
}

function NullDNDDrop(event) {
    event.stopPropagation();
    event.preventDefault();
}

function DnDDragOver(event) {
    event.stopPropagation();
    event.preventDefault();

    event.originalEvent.dataTransfer.dropEffect = ((userPermissions & PermissionFlags.FileUpload) > 0) ? 'copy' : 'none';
}

function DnDDragDrop(event) {
    event.stopPropagation();
    event.preventDefault();

    if ((userPermissions & PermissionFlags.FileUpload) == 0) { return; }

    if (navigator.appName.indexOf("Internet Explorer") != -1) {
        showModal("Not supported", "Sorry, file uploads are not available on Internet Explorer at this time.", Icons.Info, hideModal, null, null);
        return;
    }

    var files = event.originalEvent.dataTransfer.files;

    for (var i = 0; i < files.length; i++) {
        var file = files[i];

        if (file.name.indexOf(".") === -1) {
            showModal("Folder Upload Unsupported", "Sorry, browser security restrictions don't allow entire folders to be uploaded.", Icons.Warning, hideModal, null, null);
            continue;
        }

        var job = new fileUploadJob();
        job.path = fileManagerPath + file.name;
        job.name = file.name;
        job.fileLength = file.size;
        job.taskID = createTask("Uploading file '{0}'".format(job.name));

        var reader = new FileReader();
        reader.onload = function (event) {
            job.data = event.target.result;
            uploadNextChunk(job);
        };
        reader.readAsArrayBuffer(file);
    }
}

function fileUploadJob() {
    this.data = null;
    this.taskID = 0;
    this.currentOffset = 0;
    this.path = "";
    this.file = "";
    this.fileLength = 0;
}

function fileDownloadJob() {
    this.data = "";
    this.fileLength = 0;
    this.taskID = 0;
    this.currentOffset = 0;
    this.path = "";
    this.file = "";
}

var downloadChunkSize = 512 * 1024;
var uploadChunkSize = 256 * 1024;

function fileDownload(e) {
    var row = $(this);
    var path = row.data("path");
    var name = row.data("name");
    var size = parseInt(row.data("size"));

    var job = new fileDownloadJob();
    job.path = path;
    job.name = name;
    job.fileLength = size;
    job.taskID = createTask("Downloading file '{0}'".format(job.name));

    getNextDownloadChunk(job);
}

function base64toBlob(byteCharacters, contentType) {
    contentType = contentType || '';
    var sliceSize = 1024;
    var bytesLength = byteCharacters.length;
    var slicesCount = Math.ceil(bytesLength / sliceSize);
    var byteArrays = new Array(slicesCount);

    for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
        var begin = sliceIndex * sliceSize;
        var end = Math.min(begin + sliceSize, bytesLength);

        var bytes = new Array(end - begin);
        for (var offset = begin, i = 0 ; offset < end; ++i, ++offset) {
            bytes[i] = byteCharacters[offset].charCodeAt(0);
        }
        byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
}

function arrayBufferToBase64(buffer) {
    var binary = '';
    var bytes = new Uint8Array(buffer);
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i])
    }
    return window.btoa(binary);
}

function fileManagerClick(e)
{
    if (e.which === 3)
    {
        
    }
}

function uploadNextChunk(job) {
    var dataChunk = job.data.slice(job.currentOffset, Math.min(job.currentOffset + uploadChunkSize, job.fileLength));
    //var dataChunk = job.data.substr(job.currentOffset, uploadChunkSize);
    var asBase64 = arrayBufferToBase64(dataChunk);

    requestData(APICommands.WriteFileChunk, { Path: job.path, start: job.currentOffset, data: asBase64 }, function (data) {
        if (data == null) {
            endTask(job.taskID);
            job.data = null;
            return;
        }

        job.currentOffset += uploadChunkSize;

        if (job.currentOffset >= job.fileLength) {
            endTask(job.taskID);
            job.data = null;
            getListing();
        }
        else {
            var progress = Math.floor((job.currentOffset / job.fileLength) * 100);
            setTaskStatus(job.taskID, progress);
            uploadNextChunk(job);
        }
    }, true);
}

function getNextDownloadChunk(job) {
    requestData(APICommands.GetFileChunk, { Path: job.path, start: job.currentOffset, length: downloadChunkSize }, function (data) {
        if (data == null) {
            endTask(job.taskID);
            job.data = "";
            return;
        }

        var byteChars = atob(data.data);
        job.data = job.data + byteChars;
        job.currentOffset += downloadChunkSize;

        if (job.currentOffset >= job.fileLength) {
            var blob = base64toBlob(job.data, "application/octet-stream");
            var url = window.URL.createObjectURL(blob);
            endTask(job.taskID);
            downloadInProgress = false;

            saveAs(blob, job.name);

            job.data = "";
        }
        else {
            var progress = Math.floor((job.currentOffset / job.fileLength) * 100);
            setTaskStatus(job.taskID, progress);
            getNextDownloadChunk(job);
        }
    });
}

function listingClicked(event) {
    if (event.which === 1) { //Left Click
        if (!event.ctrlKey) {
            $("#fmContents .selected").removeClass("selected");
        }

        var thisEntry = $(this);

        if (thisEntry.data("type") == "File" && thisEntry.hasClass("downloadable")) {
            thisEntry.addClass("selected");
        }
        else if (thisEntry.data("type") == "Folder") {
            var path = thisEntry.data("name");

            if (path == "..") {
                var parts = fileManagerPath.split("/");
                parts.pop();
                parts.pop();
                fileManagerPath = parts.join("/");
                if (parts.length > 0) {
                    fileManagerPath = fileManagerPath + "/";
                }
            }
            else {
                fileManagerPath += thisEntry.data("name") + "/";
            }
            getListing();
        }
    }
    else if (event.which === 3) //Right Click
    {

    }
}

/////////////////////////////////////
//Cookies
/////////////////////////////////////

function setCookie(key, value) {
    localStorage[key] = value;
}

function getCookie(key) {
    return localStorage[key];
}
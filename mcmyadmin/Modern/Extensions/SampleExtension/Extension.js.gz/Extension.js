﻿//Make sure to replace 'Extensions.SampleExtension' below with 'Extensions.YourExtensionName'

Extensions.SampleExtension = {};
Extensions.SampleExtension.CreateTab = true;
Extensions.SampleExtension.Name = "Sample Extension";
Extensions.SampleExtension.Author = "Joe Bloggs";
Extensions.SampleExtension.TabTitle = "Sample Extension";

Extensions.SampleExtension.Init = function () {
    //Stuff to do at startup.
};